import { db } from "./index.js";
import { users } from "../shared/schema.js";
import { hashPassword } from "../server/auth.js";
import { eq } from "drizzle-orm";

/**
 * This script fixes all users with improperly formatted passwords by resetting them to a default
 * and notifying which users need password resets.
 */

async function fixAllPasswords() {
  console.log("Starting password fix process...");
  
  try {
    // Get all users
    const allUsers = await db.query.users.findMany();
    console.log(`Found ${allUsers.length} users to check`);
    
    const usersNeedingFix = [];
    
    for (const user of allUsers) {
      const password = user.password;
      
      // Check if password has proper format (salt.hash)
      if (!password || !password.includes(".")) {
        console.log(`❌ User ${user.email} has invalid password format`);
        usersNeedingFix.push(user);
        continue;
      }
      
      const [salt, hash] = password.split(".");
      
      // Check if hash is proper hex and 128 chars (64 bytes * 2)
      if (!salt || !hash || hash.length !== 128 || !/^[0-9a-f]+$/i.test(hash)) {
        console.log(`❌ User ${user.email} has malformed password hash`);
        usersNeedingFix.push(user);
        continue;
      }
      
      console.log(`✅ User ${user.email} has valid password format`);
    }
    
    if (usersNeedingFix.length === 0) {
      console.log("✅ All passwords are in correct format!");
      return;
    }
    
    console.log(`\n🔧 Fixing ${usersNeedingFix.length} users with invalid passwords...`);
    
    // Fix each user with a default password
    for (const user of usersNeedingFix) {
      const defaultPassword = "password123"; // Users will need to reset this
      const hashedPassword = await hashPassword(defaultPassword);
      
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.id, user.id));
      
      console.log(`✅ Fixed password for ${user.email} (default: password123)`);
    }
    
    console.log(`\n📋 IMPORTANT: The following users need to reset their passwords:`);
    console.log(`Default password is: password123`);
    console.log(`Users that need password reset:`);
    
    usersNeedingFix.forEach(user => {
      console.log(`- ${user.email} (${user.name})`);
    });
    
    console.log("\n✅ Password fix completed successfully!");
    
  } catch (error) {
    console.error("❌ Error fixing passwords:", error);
    process.exit(1);
  }
}

// Run the fix
fixAllPasswords()
  .then(() => {
    console.log("Password fix process completed.");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Password fix failed:", error);
    process.exit(1);
  });