import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return salt + "." + buf.toString("hex");
}

async function seed() {
  try {
    console.log("Seeding database...");

    // Create initial funds record
    const existingFunds = await db.select().from(schema.funds).limit(1);
    if (existingFunds.length === 0) {
      await db.insert(schema.funds).values({
        onhandCash: 350000,
        capitalFund: 2450000,
        reserveFund: 500000,
      });
      console.log("Created initial funds record");
    }

    // Create admin user
    const adminEmail = "admin@hopempc.org";
    const existingAdmin = await db.select().from(schema.users).where(eq(schema.users.email, adminEmail)).limit(1);
    
    if (existingAdmin.length === 0) {
      await db.insert(schema.users).values({
        name: "System Administrator",
        email: adminEmail,
        password: await hashPassword("admin123"),
        role: "admin",
        status: "active",
      });
      console.log("Created admin user");
      console.log("Admin credentials:");
      console.log("Email: admin@hopempc.org");
      console.log("Password: admin123");
    }

    // Create sample member
    const memberEmail = "member@hopempc.org";
    const existingMember = await db.select().from(schema.users).where(eq(schema.users.email, memberEmail)).limit(1);
    
    if (existingMember.length === 0) {
      const member = await db.insert(schema.users).values({
        name: "Sample Member",
        firstName: "John",
        lastName: "Doe",
        email: memberEmail,
        password: await hashPassword("member123"),
        role: "member",
        status: "active",
        address: "123 Main St",
        contactNumber: "09123456789",
        occupation: "Teacher",
        civilStatus: "Single",
      }).returning();

      // Add capital share for the member
      await db.insert(schema.capitalShares).values({
        userId: member[0].id,
        amount: 5000,
      });

      console.log("Created sample member with capital share");
      console.log("Member credentials:");
      console.log("Email: member@hopempc.org");
      console.log("Password: member123");
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

seed();