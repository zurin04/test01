import MemberLayout from "@/layouts/member-layout";
import { OfficerChat } from "@/components/officer-chat";

export default function MemberChat() {
  return (
    <MemberLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Officer Chat</h1>
          <p className="text-muted-foreground">
            Communicate with other officers and administrators
          </p>
        </div>
        
        <div className="h-[calc(100vh-12rem)]">
          <OfficerChat />
        </div>
      </div>
    </MemberLayout>
  );
}