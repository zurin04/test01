import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { 
  Users, Coins, HandCoins, BanknoteIcon, TrendingUp, 
  ArrowUpRight, ArrowDownRight, BarChart3
} from "lucide-react";
import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Loan, Payment, User, Fund, MonthlyIncome, MonthlyExpense, NewsFeed } from "@shared/schema";

export default function AdminDashboard() {
  // Fetch active members
  const { data: activeMembers, isLoading: isLoadingMembers } = useQuery<User[]>({
    queryKey: ["/api/admin/members/active"],
  });

  // Fetch funds
  const { data: funds, isLoading: isLoadingFunds } = useQuery<Fund>({
    queryKey: ["/api/admin/funds"],
  });

  // Fetch active loans
  const { data: loans, isLoading: isLoadingLoans } = useQuery<Loan[]>({
    queryKey: ["/api/admin/loans"],
  });

  // Fetch news
  const { data: news, isLoading: isLoadingNews } = useQuery<NewsFeed[]>({
    queryKey: ["/api/admin/news"],
  });

  // Calculate metrics
  const totalMembers = activeMembers?.length || 0;
  const totalCapitalFund = funds?.capitalFund || 0;
  const activeLoansAmount = loans?.reduce((sum, loan) => sum + loan.balance, 0) || 0;
  const onHandCash = funds?.onhandCash || 0;

  // Get current month and year for income/expenses
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth() + 1; // JavaScript months are 0-indexed
  const currentYear = currentDate.getFullYear();

  // Fetch monthly income
  const { data: monthlyIncome, isLoading: isLoadingIncome } = useQuery<MonthlyIncome[]>({
    queryKey: [`/api/admin/income?year=${currentYear}&month=${currentMonth}`],
  });

  // Fetch monthly expenses
  const { data: monthlyExpenses, isLoading: isLoadingExpenses } = useQuery<MonthlyExpense[]>({
    queryKey: [`/api/admin/expenses?year=${currentYear}&month=${currentMonth}`],
  });

  // Calculate income and expenses totals
  const totalIncome = monthlyIncome?.reduce((sum, income) => sum + income.amount, 0) || 0;
  const totalExpenses = monthlyExpenses?.reduce((sum, expense) => sum + expense.amount, 0) || 0;
  const netProfit = totalIncome - totalExpenses;

  // Recent loans for display in the dashboard
  const recentLoans = loans?.slice(0, 4) || [];

  // Recent payments - this would typically come from an API
  // For now, we'll just mock this with empty data since we don't have a direct endpoint
  const recentPayments: any[] = [];

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
      
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Total Members</p>
                {isLoadingMembers ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">{totalMembers}</h3>
                )}
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="mr-1 h-3 w-3" /> 8%
              </span>
              <span className="text-gray-500 dark:text-gray-400 ml-2">since last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Total Capital Fund</p>
                {isLoadingFunds ? (
                  <Skeleton className="h-8 w-28 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">
                    ₱{totalCapitalFund.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </h3>
                )}
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                <Coins className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="mr-1 h-3 w-3" /> 12%
              </span>
              <span className="text-gray-500 dark:text-gray-400 ml-2">since last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Active Loans</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-28 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">
                    ₱{activeLoansAmount.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </h3>
                )}
              </div>
              <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-md">
                <HandCoins className="h-5 w-5 text-orange-600 dark:text-orange-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-green-500 flex items-center">
                <ArrowUpRight className="mr-1 h-3 w-3" /> 5%
              </span>
              <span className="text-gray-500 dark:text-gray-400 ml-2">since last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">On-Hand Cash</p>
                {isLoadingFunds ? (
                  <Skeleton className="h-8 w-28 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">
                    ₱{onHandCash.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </h3>
                )}
              </div>
              <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-md">
                <BanknoteIcon className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-red-500 flex items-center">
                <ArrowDownRight className="mr-1 h-3 w-3" /> 3%
              </span>
              <span className="text-gray-500 dark:text-gray-400 ml-2">since last month</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Recent Loans */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Recent Loans</h2>
              <Link href="/admin/loans">
                <Button variant="link" className="text-sm">View all</Button>
              </Link>
            </div>
            
            {isLoadingLoans ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : recentLoans.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Member</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentLoans.map((loan) => (
                      <TableRow key={loan.id}>
                        <TableCell className="font-medium">ID: {loan.userId}</TableCell>
                        <TableCell>
                          ₱{loan.amount.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          })}
                        </TableCell>
                        <TableCell>{format(new Date(loan.createdAt), "MMM dd, yyyy")}</TableCell>
                        <TableCell>
                          <Badge 
                            className={`${
                              loan.status === 'active' ? 'bg-green-500' : 
                              loan.status === 'pending' ? 'bg-yellow-500' : 
                              loan.status === 'rejected' ? 'bg-red-500' : 
                              'bg-blue-500'
                            }`}
                          >
                            {loan.status.charAt(0).toUpperCase() + loan.status.slice(1)}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                No recent loans available.
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Recent Payments */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Recent Payments</h2>
              <Link href="/admin/payments">
                <Button variant="link" className="text-sm">View all</Button>
              </Link>
            </div>
            
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No recent payments available.
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Monthly Finance Summary and Newsfeed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Finance Summary */}
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">Monthly Finance Summary</h2>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                  Income vs Expenses ({format(currentDate, "MMMM yyyy")})
                </h3>
                
                {isLoadingIncome || isLoadingExpenses ? (
                  <Skeleton className="h-10 w-full" />
                ) : (
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-green-500 rounded-full" 
                      style={{ 
                        width: totalIncome === 0 ? '0%' : 
                          `${Math.min(100, (totalIncome / (totalIncome + totalExpenses)) * 100)}%` 
                      }}
                    ></div>
                  </div>
                )}
                
                <div className="flex justify-between mt-2 text-sm">
                  <div>
                    <span className="font-medium text-gray-800 dark:text-gray-200">Income: </span>
                    <span className="text-gray-600 dark:text-gray-400">
                      ₱{totalIncome.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}
                    </span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800 dark:text-gray-200">Expenses: </span>
                    <span className="text-gray-600 dark:text-gray-400">
                      ₱{totalExpenses.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Top Income Source</p>
                  <p className="font-medium mt-1 text-gray-800 dark:text-gray-200">Loan Interest</p>
                  <p className="text-lg font-bold text-green-600 dark:text-green-400 mt-1">₱45,000</p>
                </div>
                
                <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Top Expense</p>
                  <p className="font-medium mt-1 text-gray-800 dark:text-gray-200">Operations</p>
                  <p className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">₱32,000</p>
                </div>
              </div>
              
              <div className="text-right mt-2">
                <Link href="/admin/income-expenses">
                  <Button variant="link" className="text-sm">
                    View detailed report <ArrowUpRight className="ml-1 h-3 w-3" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Admin Newsfeed */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Cooperative Updates</h2>
              <Link href="/admin/newsfeed">
                <Button variant="link" className="text-sm">Manage all updates</Button>
              </Link>
            </div>
            
            {isLoadingNews ? (
              <div className="space-y-4">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : news && news.length > 0 ? (
              <div className="space-y-4 mb-4">
                {news.slice(0, 2).map((item) => (
                  <div key={item.id} className="border-l-4 border-primary pl-4 py-2">
                    <h3 className="font-medium text-gray-800 dark:text-gray-200">{item.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {item.content.length > 50 ? `${item.content.substring(0, 50)}...` : item.content}
                    </p>
                    <div className="mt-2 flex justify-between items-center">
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        Posted on {format(new Date(item.createdAt), "MMM dd, yyyy")}
                      </span>
                      <div className="flex space-x-2">
                        <Link href={`/admin/newsfeed?edit=${item.id}`}>
                          <Button variant="ghost" size="sm" className="h-8 px-2 text-blue-600 hover:text-blue-500 dark:text-blue-400">
                            <TrendingUp className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                No updates available.
              </div>
            )}
            
            {/* Add new update form */}
            <div className="mt-6 border-t border-gray-200 dark:border-gray-700 pt-4">
              <h3 className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-2">Quick Post Update</h3>
              <Link href="/admin/newsfeed?new=true">
                <Button className="w-full">
                  Create New Update
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
