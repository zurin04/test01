import AdminLayout from "@/layouts/admin-layout";
import { OfficerChat } from "@/components/officer-chat";

export default function AdminChatPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Officers Chat</h1>
          <p className="text-muted-foreground">
            Real-time communication with officers and administrators
          </p>
        </div>
        
        <div className="h-[calc(100vh-12rem)]">
          <OfficerChat />
        </div>
      </div>
    </AdminLayout>
  );
}
