#!/bin/bash

# Production Nginx Fix Script for VPS Deployment
# This script fixes the Nginx default page issue on your VPS

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${BLUE}▶${NC} $1"; }
print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }
print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }

APP_DIR="/opt/crypto-airdrop"

print_status "Detecting application port..."

# Detect application port
APP_PORT="5000"
if [ -f "$APP_DIR/package.json" ]; then
    if grep -q "3000\|vite\|react-scripts" "$APP_DIR/package.json"; then
        APP_PORT="3000"
    fi
fi

print_status "Application port detected: $APP_PORT"

print_status "Creating Nginx site configuration..."

# Create the Nginx configuration for crypto-airdrop
sudo tee /etc/nginx/sites-available/crypto-airdrop > /dev/null << EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    client_max_body_size 100M;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=uploads:10m rate=1r/s;
    
    # Main application
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # API rate limiting
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Upload rate limiting
    location /api/upload {
        limit_req zone=uploads burst=5 nodelay;
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

print_success "Nginx configuration created"

print_status "Removing all existing site configurations..."
sudo rm -f /etc/nginx/sites-enabled/*

print_status "Enabling crypto-airdrop site..."
sudo ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/

print_status "Testing Nginx configuration..."
if sudo nginx -t; then
    print_success "Nginx configuration is valid"
else
    print_error "Nginx configuration has errors"
    exit 1
fi

print_status "Restarting Nginx..."
sudo systemctl restart nginx

if sudo systemctl is-active --quiet nginx; then
    print_success "Nginx restarted successfully"
else
    print_error "Nginx failed to restart"
    sudo systemctl status nginx
    exit 1
fi

print_status "Checking application status..."
if netstat -tlnp 2>/dev/null | grep -q ":$APP_PORT "; then
    print_success "Application is running on port $APP_PORT"
else
    print_warning "Application may not be running on port $APP_PORT"
    echo "Check PM2 status: pm2 status"
fi

# Test connectivity
print_status "Testing connectivity..."
sleep 2

# Test localhost
if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|302"; then
    print_success "Application responds correctly on localhost"
else
    print_warning "Application not responding on localhost"
fi

# Get server IP
server_ip=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
           curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
           hostname -I | awk '{print $1}' || \
           echo "localhost")

if [[ "$server_ip" != "localhost" ]]; then
    if curl -s -o /dev/null -w "%{http_code}" http://$server_ip | grep -q "200\|302"; then
        print_success "Application responds correctly on external IP"
    else
        print_warning "Application not responding on external IP (may be firewall)"
    fi
fi

echo ""
print_success "Nginx fix completed!"
echo ""
echo "Your application should now be accessible at:"
echo "• http://$server_ip"
echo ""
echo "If you still see the Nginx welcome page:"
echo "1. Wait 30 seconds for changes to propagate"
echo "2. Clear your browser cache (Ctrl+F5)"
echo "3. Check PM2 status: pm2 status"
echo "4. Check application logs: pm2 logs crypto-airdrop"