#!/bin/bash

# Crypto Airdrop Platform Health Check Script
# Comprehensive system health verification

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[CHECK]${NC} $1"; }
print_success() { echo -e "${GREEN}[PASS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[FAIL]${NC} $1"; }

HEALTH_SCORE=0
TOTAL_CHECKS=0
APP_DIR="/var/www/crypto-airdrop"

# Function to increment counters
check_passed() {
    HEALTH_SCORE=$((HEALTH_SCORE + 1))
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
}

check_failed() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
}

# Check system services
check_system_services() {
    echo ""
    print_status "Checking system services..."
    
    # PostgreSQL
    if systemctl is-active --quiet postgresql; then
        print_success "PostgreSQL is running"
        check_passed
    else
        print_error "PostgreSQL is not running"
        check_failed
    fi
    
    # Nginx
    if systemctl is-active --quiet nginx; then
        print_success "Nginx is running"
        check_passed
    else
        print_error "Nginx is not running"
        check_failed
    fi
    
    # UFW Firewall
    if sudo ufw status | grep -q "Status: active"; then
        print_success "UFW firewall is active"
        check_passed
    else
        print_warning "UFW firewall is not active"
        check_failed
    fi
}

# Check application
check_application() {
    echo ""
    print_status "Checking application..."
    
    # PM2 process
    if pm2 list | grep -q "crypto-airdrop.*online"; then
        print_success "Application is running (PM2)"
        check_passed
    else
        print_error "Application is not running (PM2)"
        check_failed
    fi
    
    # Application directory
    if [ -d "$APP_DIR" ]; then
        print_success "Application directory exists"
        check_passed
    else
        print_error "Application directory not found"
        check_failed
    fi
    
    # Environment file
    if [ -f "$APP_DIR/.env" ]; then
        print_success "Environment file exists"
        check_passed
    else
        print_error "Environment file not found"
        check_failed
    fi
    
    # Built application
    if [ -d "$APP_DIR/dist" ]; then
        print_success "Application is built"
        check_passed
    else
        print_warning "Application build directory not found"
        check_failed
    fi
}

# Check database connectivity
check_database() {
    echo ""
    print_status "Checking database..."
    
    if [ -f "$APP_DIR/.env" ]; then
        source "$APP_DIR/.env"
        
        # Test database connection
        if psql "$DATABASE_URL" -c "SELECT 1;" >/dev/null 2>&1; then
            print_success "Database connection successful"
            check_passed
        else
            print_error "Database connection failed"
            check_failed
        fi
        
        # Check if tables exist
        if psql "$DATABASE_URL" -c "\dt" | grep -q "users\|airdrops"; then
            print_success "Database tables exist"
            check_passed
        else
            print_warning "Database tables may not be initialized"
            check_failed
        fi
    else
        print_error "Cannot check database - environment file missing"
        check_failed
    fi
}

# Check network connectivity
check_network() {
    echo ""
    print_status "Checking network connectivity..."
    
    # Check if port 5000 is listening
    if netstat -tlnp 2>/dev/null | grep -q ":5000 "; then
        print_success "Application port (5000) is listening"
        check_passed
    else
        print_error "Application port (5000) is not listening"
        check_failed
    fi
    
    # Check if port 80 is listening
    if netstat -tlnp 2>/dev/null | grep -q ":80 "; then
        print_success "HTTP port (80) is listening"
        check_passed
    else
        print_error "HTTP port (80) is not listening"
        check_failed
    fi
    
    # Test HTTP response
    if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|302\|404"; then
        print_success "HTTP endpoint responding"
        check_passed
    else
        print_error "HTTP endpoint not responding"
        check_failed
    fi
}

# Check system resources
check_resources() {
    echo ""
    print_status "Checking system resources..."
    
    # Memory usage
    MEMORY_USAGE=$(free | awk 'FNR==2{printf "%.0f", $3/$2*100}')
    if [ "$MEMORY_USAGE" -lt 80 ]; then
        print_success "Memory usage: ${MEMORY_USAGE}% (OK)"
        check_passed
    else
        print_warning "Memory usage: ${MEMORY_USAGE}% (High)"
        check_failed
    fi
    
    # Disk usage
    DISK_USAGE=$(df / | awk 'FNR==2{print $5}' | sed 's/%//')
    if [ "$DISK_USAGE" -lt 90 ]; then
        print_success "Disk usage: ${DISK_USAGE}% (OK)"
        check_passed
    else
        print_warning "Disk usage: ${DISK_USAGE}% (High)"
        check_failed
    fi
    
    # Load average
    LOAD_AVG=$(uptime | awk -F'load average:' '{ print $2 }' | awk '{ print $1 }' | sed 's/,//')
    CPU_CORES=$(nproc)
    if (( $(echo "$LOAD_AVG < $CPU_CORES" | bc -l) )); then
        print_success "Load average: $LOAD_AVG (OK for $CPU_CORES cores)"
        check_passed
    else
        print_warning "Load average: $LOAD_AVG (High for $CPU_CORES cores)"
        check_failed
    fi
}

# Check logs for errors
check_logs() {
    echo ""
    print_status "Checking recent logs..."
    
    # Check application logs
    if [ -f "$APP_DIR/logs/err.log" ]; then
        ERROR_COUNT=$(tail -100 "$APP_DIR/logs/err.log" 2>/dev/null | wc -l)
        if [ "$ERROR_COUNT" -eq 0 ]; then
            print_success "No recent application errors"
            check_passed
        else
            print_warning "Found $ERROR_COUNT recent application errors"
            check_failed
        fi
    else
        print_warning "Application error log not found"
        check_failed
    fi
    
    # Check Nginx errors
    if [ -f "/var/log/nginx/error.log" ]; then
        NGINX_ERRORS=$(sudo tail -100 /var/log/nginx/error.log 2>/dev/null | wc -l)
        if [ "$NGINX_ERRORS" -eq 0 ]; then
            print_success "No recent Nginx errors"
            check_passed
        else
            print_warning "Found $NGINX_ERRORS recent Nginx errors"
            check_failed
        fi
    else
        print_warning "Nginx error log not found"
        check_failed
    fi
}

# Check security
check_security() {
    echo ""
    print_status "Checking security configuration..."
    
    # Check SSL certificates (if any)
    if [ -d "/etc/letsencrypt/live" ] && [ "$(ls -A /etc/letsencrypt/live 2>/dev/null)" ]; then
        print_success "SSL certificates found"
        check_passed
    else
        print_warning "No SSL certificates found (HTTP only)"
        check_failed
    fi
    
    # Check file permissions
    if [ -f "$APP_DIR/.env" ]; then
        ENV_PERMS=$(stat -c "%a" "$APP_DIR/.env")
        if [ "$ENV_PERMS" = "600" ] || [ "$ENV_PERMS" = "644" ]; then
            print_success "Environment file permissions secure"
            check_passed
        else
            print_warning "Environment file permissions: $ENV_PERMS (consider 600)"
            check_failed
        fi
    fi
    
    # Check for exposed sensitive files
    if [ ! -f "$APP_DIR/.git/config" ] || [ ! -d "$APP_DIR/.git" ]; then
        print_success "No Git repository exposed"
        check_passed
    else
        print_warning "Git repository found in web directory"
        check_failed
    fi
}

# Display final results
display_results() {
    echo ""
    echo "======================================"
    echo "HEALTH CHECK RESULTS"
    echo "======================================"
    
    HEALTH_PERCENTAGE=$((HEALTH_SCORE * 100 / TOTAL_CHECKS))
    
    echo "Checks passed: $HEALTH_SCORE/$TOTAL_CHECKS ($HEALTH_PERCENTAGE%)"
    
    if [ "$HEALTH_PERCENTAGE" -ge 90 ]; then
        echo -e "${GREEN}Overall Status: EXCELLENT${NC}"
    elif [ "$HEALTH_PERCENTAGE" -ge 75 ]; then
        echo -e "${YELLOW}Overall Status: GOOD${NC}"
    elif [ "$HEALTH_PERCENTAGE" -ge 50 ]; then
        echo -e "${YELLOW}Overall Status: FAIR - Attention needed${NC}"
    else
        echo -e "${RED}Overall Status: POOR - Immediate attention required${NC}"
    fi
    
    echo ""
    echo "System Information:"
    echo "- Uptime: $(uptime -p)"
    echo "- Memory: $(free -h | awk '/^Mem:/ {print $3 "/" $2}')"
    echo "- Disk: $(df -h / | awk '/\// {print $3 "/" $2 " (" $5 ")"}')"
    echo "- Load: $(uptime | awk -F'load average:' '{print $2}')"
    
    if [ -f "$APP_DIR/.env" ]; then
        source "$APP_DIR/.env"
        echo "- Node.js: $(node --version 2>/dev/null || echo 'Not found')"
        echo "- PM2: $(pm2 --version 2>/dev/null || echo 'Not found')"
        echo "- Environment: ${NODE_ENV:-development}"
    fi
    
    echo ""
    echo "Quick Actions:"
    echo "- View application logs: pm2 logs crypto-airdrop"
    echo "- Restart application: $APP_DIR/manage.sh restart"
    echo "- Check service status: $APP_DIR/manage.sh status"
    echo "- Create backup: $APP_DIR/manage.sh backup"
    
    if [ "$HEALTH_PERCENTAGE" -lt 75 ]; then
        echo ""
        echo -e "${YELLOW}Recommendations:${NC}"
        echo "1. Check the logs for detailed error information"
        echo "2. Restart failed services"
        echo "3. Verify environment configuration"
        echo "4. Consider checking the deployment guide"
    fi
}

# Main execution
main() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    Crypto Airdrop Platform Health Check                      ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    
    check_system_services
    check_application
    check_database
    check_network
    check_resources
    check_logs
    check_security
    display_results
}

# Execute main function
main "$@"