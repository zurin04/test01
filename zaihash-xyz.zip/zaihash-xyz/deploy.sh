#!/bin/bash

# Crypto Airdrop Platform - Single Script VPS Deployment
# Comprehensive automated deployment with enhanced PM2 handling

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Logging functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Configuration
APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
NODE_VERSION="20"
APP_PORT="5000"
DOMAIN=""

# Generated variables
DB_NAME="crypto_airdrop_prod"
DB_USER="crypto_app"
DB_PASSWORD=""
SESSION_SECRET=""
SERVER_IP=""

print_header() {
    echo ""
    echo -e "${PURPLE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║          Crypto Airdrop Platform - VPS Deployment           ║${NC}"
    echo -e "${PURPLE}║               Enhanced Single Script Deploy                  ║${NC}"
    echo -e "${PURPLE}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Enhanced user check
check_user() {
    if [[ $EUID -eq 0 ]]; then
        log_error "Do not run this script as root. Use a user with sudo privileges."
        exit 1
    fi
    
    if ! sudo -n true 2>/dev/null; then
        log_error "This script requires sudo privileges. Please run with a user that has sudo access."
        exit 1
    fi
    
    log_info "User check passed ($(whoami))"
}

# Check OS compatibility
check_os() {
    if ! grep -qE "(Ubuntu|Debian)" /etc/os-release; then
        log_warning "This script is optimized for Ubuntu/Debian. Proceeding anyway..."
        sleep 3
    fi
    
    # Check system resources
    TOTAL_MEM=$(free -m | awk '/^Mem:/ {print $2}')
    if [[ $TOTAL_MEM -lt 1024 ]]; then
        log_warning "Low memory detected (${TOTAL_MEM}MB). Consider upgrading your VPS."
    fi
    
    log_info "OS check completed"
}

# Generate secure passwords
generate_secrets() {
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    SESSION_SECRET=$(openssl rand -base64 64 | tr -d "=+/" | cut -c1-50)
}

# Enhanced system update
update_system() {
    log_info "Updating system packages..."
    
    # Update package list
    sudo apt update -y > /dev/null 2>&1
    
    # Install essential packages first
    sudo apt install -y curl wget gnupg2 software-properties-common apt-transport-https > /dev/null 2>&1
    
    # Upgrade system
    sudo DEBIAN_FRONTEND=noninteractive apt upgrade -y > /dev/null 2>&1
    
    log_success "System updated"
}

# Enhanced dependency installation
install_dependencies() {
    log_info "Installing system dependencies..."
    
    # Install PostgreSQL
    if ! command -v psql &>/dev/null; then
        log_info "Installing PostgreSQL..."
        sudo apt install -y postgresql postgresql-contrib > /dev/null 2>&1
        sudo systemctl enable --now postgresql > /dev/null 2>&1
    fi
    
    # Install Nginx  
    if ! command -v nginx &>/dev/null; then
        log_info "Installing Nginx..."
        sudo apt install -y nginx > /dev/null 2>&1
        sudo systemctl enable --now nginx > /dev/null 2>&1
    fi
    
    # Install other dependencies
    sudo apt install -y git unzip build-essential ufw openssl > /dev/null 2>&1
    
    # Install Node.js 20
    if ! command -v node &>/dev/null || [[ $(node -v | cut -d'v' -f2 | cut -d'.' -f1) -lt 20 ]]; then
        log_info "Installing Node.js ${NODE_VERSION}..."
        curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | sudo -E bash - > /dev/null 2>&1
        sudo apt install -y nodejs > /dev/null 2>&1
    fi
    
    # Install PM2 globally
    if ! command -v pm2 &>/dev/null; then
        log_info "Installing PM2..."
        sudo npm install -g pm2@latest > /dev/null 2>&1
        
        # Configure PM2 startup
        PM2_STARTUP_CMD=$(pm2 startup | tail -n 1)
        if [[ $PM2_STARTUP_CMD == sudo* ]]; then
            eval "$PM2_STARTUP_CMD" > /dev/null 2>&1
        fi
    fi
    
    log_success "Dependencies installed (Node.js $(node -v), PM2 $(pm2 -v))"
}

# Enhanced database setup
setup_database() {
    log_info "Setting up PostgreSQL database..."
    
    # Start PostgreSQL if not running
    sudo systemctl start postgresql
    
    # Create database and user
    sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname = '${DB_NAME}'" | grep -q 1 || \
        sudo -u postgres createdb ${DB_NAME}
    
    sudo -u postgres psql -tc "SELECT 1 FROM pg_user WHERE usename = '${DB_USER}'" | grep -q 1 || \
        sudo -u postgres createuser ${DB_USER}
    
    # Set password and permissions
    sudo -u postgres psql -c "ALTER USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
    sudo -u postgres psql -c "ALTER USER ${DB_USER} CREATEDB;"
    
    # Configure PostgreSQL for local connections
    PG_VERSION=$(sudo -u postgres psql -c "SHOW server_version;" -t | awk '{print $1}' | cut -d'.' -f1)
    PG_CONFIG="/etc/postgresql/${PG_VERSION}/main"
    
    if [[ -d $PG_CONFIG ]]; then
        # Update pg_hba.conf for local connections
        sudo sed -i "s/#local   replication     postgres                                peer/local   replication     postgres                                peer/" ${PG_CONFIG}/pg_hba.conf
        sudo sed -i "s/local   all             all                                     peer/local   all             all                                     md5/" ${PG_CONFIG}/pg_hba.conf
        
        # Restart PostgreSQL
        sudo systemctl restart postgresql
    fi
    
    log_success "Database configured"
}

# Enhanced application setup
setup_application() {
    log_info "Setting up application..."
    
    # Create application directory
    sudo mkdir -p ${APP_DIR}
    sudo chown -R $(whoami):$(whoami) ${APP_DIR}
    
    # Clone or update repository
    if [[ -d ${APP_DIR}/.git ]]; then
        log_info "Updating existing repository..."
        cd ${APP_DIR}
        git pull origin main > /dev/null 2>&1
    else
        log_info "Cloning repository..."
        # Replace with your actual repository URL
        if [[ -n "$1" ]]; then
            git clone "$1" ${APP_DIR} > /dev/null 2>&1
        else
            # If no repo provided, assume current directory is the source
            cp -r . ${APP_DIR}/
        fi
        cd ${APP_DIR}
    fi
    
    # Create environment file
    cat > .env << ENV
NODE_ENV=production
PORT=${APP_PORT}
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
SESSION_SECRET=${SESSION_SECRET}

# Additional environment variables
BCRYPT_ROUNDS=12
JWT_SECRET=${SESSION_SECRET}
CORS_ORIGIN=http://localhost:${APP_PORT}
ENV

    # Install dependencies with increased timeout
    log_info "Installing application dependencies..."
    npm ci --only=production --timeout=300000 > /dev/null 2>&1
    
    # Install development dependencies needed for build
    npm install --save-dev > /dev/null 2>&1
    
    log_success "Application setup completed"
}

# Enhanced build process
build_application() {
    log_info "Building application..."
    
    cd ${APP_DIR}
    
    # Set Node.js memory limit for build
    export NODE_OPTIONS="--max-old-space-size=4096"
    
    # Remove old build
    rm -rf dist/ > /dev/null 2>&1 || true
    
    # Build with timeout and error handling
    timeout 600 npm run build > build.log 2>&1 || {
        log_error "Build failed. Check ${APP_DIR}/build.log for details."
        echo "Last 20 lines of build log:"
        tail -20 build.log
        exit 1
    }
    
    # Verify build output
    if [[ ! -f "dist/index.js" ]]; then
        log_error "Build output not found. Build may have failed."
        exit 1
    fi
    
    log_success "Application built successfully"
}

# Database schema setup
init_database() {
    log_info "Initializing database schema..."
    
    cd ${APP_DIR}
    
    # Set environment variables for database operations
    export NODE_ENV=production
    export DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}"
    export SESSION_SECRET="${SESSION_SECRET}"
    
    # Push schema with retry logic
    for i in {1..3}; do
        if npm run db:push > /dev/null 2>&1; then
            break
        elif [[ $i -eq 3 ]]; then
            log_error "Database schema initialization failed after 3 attempts"
            exit 1
        else
            log_warning "Database schema push failed, retrying... ($i/3)"
            sleep 5
        fi
    done
    
    # Seed database
    log_info "Seeding database..."
    npm run db:seed > /dev/null 2>&1 || log_warning "Database seeding failed (continuing anyway)"
    
    log_success "Database initialized"
}

# Enhanced PM2 configuration
setup_pm2() {
    log_info "Configuring PM2..."
    
    cd ${APP_DIR}
    
    # Stop any existing processes
    pm2 delete all > /dev/null 2>&1 || true
    
    # Create comprehensive PM2 ecosystem file
    cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    max_restarts: 10,
    min_uptime: '10s',
    restart_delay: 4000,
    kill_timeout: 5000,
    wait_ready: true,
    listen_timeout: 8000
  }]
};
EOF
    
    # Create logs directory
    mkdir -p logs
    
    # Load environment variables into PM2
    if [[ -f .env ]]; then
        pm2 restart ecosystem.config.js --update-env > /dev/null 2>&1 || true
    fi
    
    # Start application
    log_info "Starting application with PM2..."
    pm2 start ecosystem.config.js > /dev/null 2>&1
    
    # Save PM2 configuration
    pm2 save > /dev/null 2>&1
    
    # Wait for application to start
    sleep 10
    
    # Verify application is running
    if ! pm2 list | grep -q "crypto-airdrop.*online"; then
        log_error "Application failed to start. Checking logs..."
        pm2 logs crypto-airdrop --lines 50
        exit 1
    fi
    
    log_success "PM2 configured and application started"
}

# Enhanced Nginx configuration
setup_nginx() {
    log_info "Configuring Nginx..."
    
    # Create rate limiting configuration
    sudo tee /etc/nginx/conf.d/rate-limiting.conf > /dev/null << 'NGINX_RATE'
# Rate limiting zones
limit_req_zone $binary_remote_addr zone=general:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=api:10m rate=30r/m;
limit_req_zone $binary_remote_addr zone=auth:10m rate=5r/m;
NGINX_RATE

    # Get server IP
    get_server_ip
    
    # Create main site configuration
    sudo tee /etc/nginx/sites-available/${APP_NAME} > /dev/null << NGINX_CONF
server {
    listen 80;
    server_name ${SERVER_IP} ${DOMAIN};
    client_max_body_size 10M;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Rate limiting
    limit_req zone=general burst=20 nodelay;
    
    # Static file handling
    location ~* \\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files \$uri @proxy;
    }
    
    # API rate limiting
    location /api/ {
        limit_req zone=api burst=10 nodelay;
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Authentication rate limiting
    location /api/auth/ {
        limit_req zone=auth burst=3 nodelay;
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # WebSocket support
    location /ws {
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Main proxy
    location @proxy {
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Default proxy for all other requests
    location / {
        try_files \$uri @proxy;
    }
}
NGINX_CONF
    
    # Enable site
    sudo ln -sf /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Test configuration
    if ! sudo nginx -t > /dev/null 2>&1; then
        log_error "Nginx configuration test failed"
        sudo nginx -t
        exit 1
    fi
    
    # Restart Nginx
    sudo systemctl restart nginx
    
    log_success "Nginx configured and restarted"
}

# Enhanced firewall setup
setup_firewall() {
    log_info "Configuring firewall..."
    
    # Reset and configure UFW
    sudo ufw --force reset > /dev/null 2>&1
    sudo ufw default deny incoming > /dev/null 2>&1
    sudo ufw default allow outgoing > /dev/null 2>&1
    
    # Allow essential ports
    sudo ufw allow 22/tcp comment 'SSH' > /dev/null 2>&1
    sudo ufw allow 80/tcp comment 'HTTP' > /dev/null 2>&1
    sudo ufw allow 443/tcp comment 'HTTPS' > /dev/null 2>&1
    
    # Enable firewall
    sudo ufw --force enable > /dev/null 2>&1
    
    log_success "Firewall configured"
}

# Enhanced application startup
start_application() {
    log_info "Final application startup verification..."
    
    cd ${APP_DIR}
    
    # Ensure PM2 is properly configured
    pm2 resurrect > /dev/null 2>&1 || true
    
    # Wait for startup
    sleep 5
    
    # Check if app is running
    if pm2 list | grep -q "crypto-airdrop.*online"; then
        log_success "Application is running successfully"
    else
        log_warning "Application may not be running properly. Attempting restart..."
        pm2 restart crypto-airdrop > /dev/null 2>&1
        sleep 5
        
        if pm2 list | grep -q "crypto-airdrop.*online"; then
            log_success "Application restarted successfully"
        else
            log_error "Application failed to start. Check logs: pm2 logs crypto-airdrop"
            exit 1
        fi
    fi
    
    # Test HTTP response
    for i in {1..5}; do
        if curl -s -o /dev/null -w "%{http_code}" http://localhost:${APP_PORT} | grep -q "200\|302"; then
            log_success "Application responding to HTTP requests"
            break
        elif [[ $i -eq 5 ]]; then
            log_warning "Application may not be responding properly to HTTP requests"
        else
            sleep 2
        fi
    done
}

# Create comprehensive management script
create_management_tools() {
    log_info "Creating management tools..."
    
    cd ${APP_DIR}
    
    # Create enhanced management script
    cat > manage.sh << 'SCRIPT'
#!/bin/bash

APP_NAME="crypto-airdrop"
APP_DIR="/var/www/crypto-airdrop"

case "$1" in
    start)
        echo "Starting application..."
        cd ${APP_DIR}
        pm2 start ${APP_NAME}
        ;;
    stop)
        echo "Stopping application..."
        pm2 stop ${APP_NAME}
        ;;
    restart)
        echo "Restarting application..."
        cd ${APP_DIR}
        pm2 restart ${APP_NAME}
        ;;
    reload)
        echo "Reloading application (zero-downtime)..."
        cd ${APP_DIR}
        pm2 reload ${APP_NAME}
        ;;
    status)
        echo "=== Application Status ==="
        pm2 status
        echo ""
        echo "=== Recent Logs ==="
        pm2 logs ${APP_NAME} --lines 20
        ;;
    logs)
        echo "Live logs (Ctrl+C to exit):"
        pm2 logs ${APP_NAME}
        ;;
    update)
        echo "Updating application..."
        cd ${APP_DIR}
        
        # Backup current version
        cp -r . ../backup-$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
        
        # Update code
        git pull
        npm ci --only=production
        npm run build
        
        # Restart application
        pm2 restart ${APP_NAME}
        echo "Update complete!"
        ;;
    backup)
        echo "Creating database backup..."
        cd ${APP_DIR}
        source .env
        mkdir -p ./backups
        pg_dump ${DATABASE_URL} > "./backups/backup_$(date +%Y%m%d_%H%M%S).sql"
        echo "Backup created in ./backups/"
        
        # Clean old backups (keep last 30 days)
        find ./backups -name "backup_*.sql" -mtime +30 -delete 2>/dev/null || true
        ;;
    restore)
        if [[ -z "$2" ]]; then
            echo "Usage: $0 restore <backup_file>"
            echo "Available backups:"
            ls -la ${APP_DIR}/backups/backup_*.sql 2>/dev/null || echo "No backups found"
            exit 1
        fi
        
        echo "Restoring database from $2..."
        cd ${APP_DIR}
        source .env
        psql ${DATABASE_URL} < "$2"
        echo "Database restored. Restarting application..."
        pm2 restart ${APP_NAME}
        ;;
    health)
        echo "=== System Health Check ==="
        
        # Check services
        if pm2 list | grep -q "${APP_NAME}.*online"; then
            echo "✅ Application: Running"
        else
            echo "❌ Application: Not running"
        fi
        
        if systemctl is-active --quiet postgresql; then
            echo "✅ PostgreSQL: Running"
        else
            echo "❌ PostgreSQL: Not running"
        fi
        
        if systemctl is-active --quiet nginx; then
            echo "✅ Nginx: Running"
        else
            echo "❌ Nginx: Not running"
        fi
        
        # Check connectivity
        if curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 | grep -q "200\|302"; then
            echo "✅ HTTP: Responding"
        else
            echo "❌ HTTP: Not responding" 
        fi
        
        # System resources
        echo ""
        echo "=== System Resources ==="
        echo "Memory: $(free -h | awk '/^Mem:/ {printf "%s/%s (%.1f%%)", $3, $2, $3/$2*100}')"
        echo "Disk: $(df -h / | awk '/\// {printf "%s/%s (%s)", $3, $2, $5}')"
        echo "Load: $(uptime | awk -F'load average:' '{print $2}')"
        
        # Check disk space
        DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
        if [[ $DISK_USAGE -gt 90 ]]; then
            echo "⚠️  Disk usage high: ${DISK_USAGE}%"
        fi
        
        # Check memory usage
        MEM_USAGE=$(free | awk 'NR==2{printf "%.1f", $3*100/$2}')
        if (( $(echo "$MEM_USAGE > 90" | bc -l) )); then
            echo "⚠️  Memory usage high: ${MEM_USAGE}%"
        fi
        ;;
    fix)
        echo "Running automated fixes..."
        
        # Restart services
        sudo systemctl restart postgresql nginx
        
        # Restart application
        cd ${APP_DIR}
        pm2 restart ${APP_NAME}
        
        # Check if fixes worked
        sleep 5
        $0 health
        ;;
    *)
        echo "Crypto Airdrop Platform Management"
        echo ""
        echo "Usage: $0 {start|stop|restart|reload|status|logs|update|backup|restore|health|fix}"
        echo ""
        echo "Commands:"
        echo "  start    - Start the application"
        echo "  stop     - Stop the application" 
        echo "  restart  - Restart the application"
        echo "  reload   - Zero-downtime reload"
        echo "  status   - Show status and recent logs"
        echo "  logs     - Show live logs"
        echo "  update   - Pull latest code and restart"
        echo "  backup   - Create database backup"
        echo "  restore  - Restore from backup file"
        echo "  health   - Complete system health check"
        echo "  fix      - Run automated fixes"
        ;;
esac
SCRIPT
    
    chmod +x manage.sh
    
    # Create daily backup cron job
    (crontab -l 2>/dev/null | grep -v "${APP_NAME} backup"; echo "0 2 * * * ${APP_DIR}/manage.sh backup > /dev/null 2>&1") | crontab -
    
    # Create weekly health check
    (crontab -l 2>/dev/null | grep -v "${APP_NAME} health"; echo "0 6 * * 0 ${APP_DIR}/manage.sh health > ${APP_DIR}/logs/health.log") | crontab -
    
    log_success "Management tools created"
}

# Get server IP
get_server_ip() {
    SERVER_IP=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
               curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
               ip route get 8.8.8.8 2>/dev/null | awk '/src/ {print $7}' || \
               echo "UNKNOWN")
}

# Enhanced deployment info
show_deployment_info() {
    get_server_ip
    
    # Create deployment info file
    cat > ${APP_DIR}/deployment-info.txt << INFO
Crypto Airdrop Platform - Production Deployment
=============================================
Deployed: $(date)
Server IP: ${SERVER_IP}
Application URL: http://${SERVER_IP}

Database Information:
- Name: ${DB_NAME}
- User: ${DB_USER}
- Password: ${DB_PASSWORD}
- URL: postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}

Application Details:
- Directory: ${APP_DIR}
- Port: ${APP_PORT}
- Environment: production
- Process Manager: PM2

Management Commands:
- Status: ${APP_DIR}/manage.sh status
- Logs: ${APP_DIR}/manage.sh logs
- Restart: ${APP_DIR}/manage.sh restart
- Health: ${APP_DIR}/manage.sh health
- Backup: ${APP_DIR}/manage.sh backup
- Fix Issues: ${APP_DIR}/manage.sh fix

Service Status:
$(${APP_DIR}/manage.sh health 2>/dev/null || echo "Run manage.sh health for detailed status")

Security Notes:
- Change default credentials after first login
- Consider setting up SSL/TLS with Certbot
- Monitor logs regularly for security issues
- Keep system packages updated

INFO
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              DEPLOYMENT COMPLETED SUCCESSFULLY!             ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}🚀 Your Crypto Airdrop Platform is now live!${NC}"
    echo ""
    echo -e "${YELLOW}Access your application:${NC}"
    echo "   🌐 http://${SERVER_IP}"
    echo ""
    echo -e "${YELLOW}Quick Management:${NC}"
    echo "   📊 ${APP_DIR}/manage.sh status    # Check status"
    echo "   📝 ${APP_DIR}/manage.sh logs      # View logs" 
    echo "   🔄 ${APP_DIR}/manage.sh restart   # Restart app"
    echo "   🏥 ${APP_DIR}/manage.sh health    # Health check"
    echo "   💾 ${APP_DIR}/manage.sh backup    # Create backup"
    echo "   🔧 ${APP_DIR}/manage.sh fix       # Auto-fix issues"
    echo ""
    echo -e "${YELLOW}Service Status:${NC}"
    
    # Real-time service check
    if systemctl is-active --quiet nginx; then
        echo "   ✅ Nginx (Port 80)"
    else
        echo "   ❌ Nginx (Port 80) - Run: sudo systemctl start nginx"
    fi
    
    if pm2 list | grep -q "${APP_NAME}.*online"; then
        echo "   ✅ Application (Port ${APP_PORT})"
    else
        echo "   ❌ Application (Port ${APP_PORT}) - Run: ${APP_DIR}/manage.sh start"
    fi
    
    if systemctl is-active --quiet postgresql; then
        echo "   ✅ PostgreSQL"
    else
        echo "   ❌ PostgreSQL - Run: sudo systemctl start postgresql"
    fi
    
    echo ""
    echo -e "${YELLOW}Next Steps:${NC}"
    echo "   1. Test: curl -I http://${SERVER_IP}"
    echo "   2. Monitor: ${APP_DIR}/manage.sh health"
    echo "   3. Set up SSL: sudo certbot --nginx -d yourdomain.com"
    echo "   4. Update admin credentials in the web interface"
    echo ""
    echo -e "${BLUE}📋 Details saved to: ${APP_DIR}/deployment-info.txt${NC}"
    echo ""
}

# Main deployment function
main() {
    print_header
    
    # Get repository URL if provided
    REPO_URL=""
    if [[ -n "$1" ]]; then
        REPO_URL="$1"
        log_info "Repository URL: $REPO_URL"
    fi
    
    # Get domain if provided
    if [[ -n "$2" ]]; then
        DOMAIN="$2"
        log_info "Domain: $DOMAIN"
    fi
    
    # Pre-deployment checks
    log_info "Starting pre-deployment checks..."
    check_user
    check_os
    generate_secrets
    
    # System setup
    log_info "Setting up system..."
    update_system
    install_dependencies
    setup_database
    
    # Application setup
    log_info "Setting up application..."
    setup_application "$REPO_URL"
    build_application
    init_database
    
    # Service configuration
    log_info "Configuring services..."
    setup_pm2
    setup_nginx
    setup_firewall
    
    # Final steps
    log_info "Finalizing deployment..."
    start_application
    create_management_tools
    show_deployment_info
    
    log_success "Deployment completed successfully!"
}

# Run main function with all arguments
main "$@"