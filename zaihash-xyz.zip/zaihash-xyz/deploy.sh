#!/bin/bash

# Crypto Airdrop Platform Production Deployment Script
# Optimized one-click deployment for Ubuntu VPS

set -e

echo "======================================"
echo "Crypto Airdrop Platform Deployment"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }

# Check prerequisites
check_prerequisites() {
    if [[ $EUID -eq 0 ]]; then
        print_error "Do not run as root. Use a regular user with sudo privileges."
        exit 1
    fi

    if ! command -v sudo >/dev/null; then
        print_error "sudo is required but not installed."
        exit 1
    fi

    # Check OS compatibility
    if ! grep -q -E "(Ubuntu|Debian)" /etc/os-release; then
        print_warning "This script is optimized for Ubuntu/Debian. Proceeding anyway..."
    fi
}

# Install system dependencies
install_system_dependencies() {
    print_status "Installing system dependencies..."
    sudo apt update -y
    sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx ufw openssl git build-essential

    # Install Node.js 20 first
    if ! command -v node &>/dev/null || [[ $(node -v 2>/dev/null | cut -d'v' -f2 | cut -d'.' -f1) -lt 20 ]]; then
        print_status "Installing Node.js 20..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
        
        # Verify Node.js installation
        if command -v node &>/dev/null && command -v npm &>/dev/null; then
            print_success "Node.js $(node -v) and npm $(npm -v) installed successfully"
        else
            print_error "Node.js installation failed"
            exit 1
        fi
    else
        print_status "Node.js $(node -v) already installed"
    fi

    # Install PM2 after Node.js is confirmed
    if ! command -v pm2 &>/dev/null; then
        print_status "Installing PM2..."
        sudo npm install -g pm2
        
        # Verify PM2 installation
        if command -v pm2 &>/dev/null; then
            print_success "PM2 installed successfully"
        else
            print_error "PM2 installation failed"
            exit 1
        fi
    else
        print_status "PM2 already installed"
    fi

    # Start and enable services
    sudo systemctl enable --now postgresql nginx
    print_success "System dependencies installed successfully"
}

# Setup PostgreSQL database
setup_database() {
    print_status "Setting up PostgreSQL database..."
    
    # Generate secure database password
    DB_PASSWORD=$(openssl rand -base64 32)
    DB_NAME="crypto_airdrop_db"
    DB_USER="crypto_user"

    # Create database and user
    sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';
ALTER USER $DB_USER CREATEDB;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\q
EOF

    print_success "Database setup completed"
    echo "Database: $DB_NAME"
    echo "User: $DB_USER"
}

# Setup application
setup_application() {
    print_status "Setting up application..."
    
    # Use /opt instead of /var/www for better permissions
    APP_DIR="/opt/crypto-airdrop"
    sudo mkdir -p $APP_DIR
    sudo chown $USER:$USER $APP_DIR
    
    # Copy application files
    print_status "Copying application files..."
    cp -r . $APP_DIR/
    cd $APP_DIR

    # Generate secure session secret
    SESSION_SECRET=$(openssl rand -hex 32)
    
    # Create environment file
    print_status "Creating environment configuration..."
    cat > .env << ENV
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
CORS_ORIGIN=http://localhost:5000
ENV

    # Install dependencies
    print_status "Installing application dependencies..."
    npm ci --production=false
    
    # Ensure tsx is available globally for PM2
    if ! command -v tsx &>/dev/null; then
        print_status "Installing tsx globally..."
        sudo npm install -g tsx
    fi

    # Setup database schema
    print_status "Initializing database schema..."
    export DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
    export SESSION_SECRET
    export NODE_ENV=production

    # Check if package.json has the required scripts
    if ! grep -q "db:push" package.json; then
        print_error "package.json missing db:push script. Adding it..."
        # Add drizzle scripts if missing
        npm pkg set scripts.db:push="drizzle-kit push"
        npm pkg set scripts.db:seed="tsx db/seed.ts"
        npm pkg set scripts.build="vite build"
        npm pkg set scripts.start="tsx server/index.ts"
    fi

    # Ensure drizzle-kit is available
    if ! command -v drizzle-kit &>/dev/null && ! npx drizzle-kit --version &>/dev/null 2>&1; then
        print_status "Installing drizzle-kit..."
        npm install -D drizzle-kit
    fi

    npm run db:push

    # Seed database with initial data
    print_status "Seeding database with initial data..."
    if [ -f "db/seed.ts" ] || [ -f "db/seed.js" ]; then
        npm run db:seed || print_warning "Database seeding failed, continuing with deployment"
    else
        print_warning "No seed file found, skipping database seeding"
    fi

    # Build application for production
    print_status "Building application for production..."
    if npm run build; then
        print_success "Application built successfully"
    else
        print_warning "Build failed, but continuing with deployment"
    fi

    # Ensure all required directories exist
    mkdir -p logs uploads
    chmod 755 logs uploads

    print_success "Application setup completed"
}

# Configure PM2
configure_pm2() {
    print_status "Configuring PM2..."
    
    cd $APP_DIR
    mkdir -p logs

    # Detect application port from package.json or environment
    APP_PORT="5000"
    if [ -f "package.json" ]; then
        # Check if port 3000 is mentioned in scripts or if it's a typical React/Vite app
        if grep -q "3000\|vite\|react-scripts" "package.json"; then
            APP_PORT="3000"
        fi
    fi

    print_status "Configuring PM2 for port $APP_PORT..."

    # Create PM2 ecosystem file with detected port
    cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    cwd: '$APP_DIR',
    env: {
      NODE_ENV: 'production',
      PORT: $APP_PORT,
      DATABASE_URL: 'postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME',
      SESSION_SECRET: '$SESSION_SECRET',
      CORS_ORIGIN: 'http://localhost:$APP_PORT'
    },
    error_file: '$APP_DIR/logs/err.log',
    out_file: '$APP_DIR/logs/out.log',
    log_file: '$APP_DIR/logs/combined.log',
    time: true
  }]
}
EOF

    print_success "PM2 configuration created for port $APP_PORT"
}

# Configure Nginx with proper default page fix
configure_nginx() {
    print_status "Configuring Nginx with default page fix..."
    
    # Detect application port from package.json or use default
    APP_PORT="5000"
    if [ -f "$APP_DIR/package.json" ]; then
        # Check if port 3000 is mentioned in scripts or if it's a typical React/Vite app
        if grep -q "3000\|vite\|react-scripts\|dev.*3000" "$APP_DIR/package.json"; then
            APP_PORT="3000"
        fi
    fi
    
    print_status "Configuring Nginx to proxy to port $APP_PORT..."
    
    # Remove ALL existing nginx site configurations (including default)
    print_status "Removing all existing Nginx site configurations..."
    sudo rm -f /etc/nginx/sites-enabled/*
    sudo rm -f /etc/nginx/sites-available/default
    
    # Create comprehensive Nginx configuration with proper routing
    sudo tee /etc/nginx/sites-available/crypto-airdrop > /dev/null << EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    client_max_body_size 100M;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # Rate limiting zones
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=uploads:10m rate=1r/s;
    
    # WebSocket support for real-time chat
    location /ws {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_buffering off;
    }
    
    # API endpoints with rate limiting
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # Upload endpoints with stricter rate limiting
    location /api/upload {
        limit_req zone=uploads burst=5 nodelay;
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Main application - proxy all other requests
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
        proxy_buffering off;
        
        # Fallback for SPA routing
        try_files \$uri \$uri/ @fallback;
    }
    
    # Fallback for single page application
    location @fallback {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

    # Enable crypto-airdrop site as the ONLY site
    print_status "Enabling crypto-airdrop site as the only active site..."
    sudo ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
    
    # Test configuration before applying
    print_status "Testing Nginx configuration..."
    if sudo nginx -t; then
        print_success "Nginx configuration is valid"
    else
        print_error "Nginx configuration has errors"
        sudo nginx -t
        exit 1
    fi
    
    # Restart Nginx to ensure clean state
    print_status "Restarting Nginx with new configuration..."
    sudo systemctl restart nginx
    
    # Verify Nginx is running properly
    if sudo systemctl is-active --quiet nginx; then
        print_success "Nginx restarted successfully"
    else
        print_error "Nginx failed to restart"
        sudo systemctl status nginx
        exit 1
    fi
    
    # Verify the site is properly enabled and no default site exists
    if [ -L "/etc/nginx/sites-enabled/crypto-airdrop" ] && [ ! -f "/etc/nginx/sites-enabled/default" ]; then
        print_success "Site enabled successfully (default site removed)"
    else
        print_warning "Site configuration may have issues"
        ls -la /etc/nginx/sites-enabled/
    fi
    
    # Wait for services to stabilize
    sleep 3
    
    # Comprehensive connectivity testing
    print_status "Testing application connectivity..."
    
    # Test localhost first
    if curl -s -f http://localhost >/dev/null 2>&1; then
        print_success "Application responds correctly on localhost"
    else
        print_warning "Application may not be responding on localhost"
        
        # Check if application is actually running
        if ! netstat -tlnp 2>/dev/null | grep -q ":$APP_PORT "; then
            print_error "Application is not running on port $APP_PORT"
            print_status "Attempting to start application..."
            
            cd $APP_DIR
            pm2 start ecosystem.config.cjs 2>/dev/null || pm2 restart all 2>/dev/null || true
            sleep 5
        fi
    fi
    
    # Get server IP for external testing
    SERVER_IP=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
               curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
               hostname -I | awk '{print $1}' 2>/dev/null || \
               echo "unknown")
    
    # Test external connectivity if we have an IP
    if [ "$SERVER_IP" != "unknown" ] && [ -n "$SERVER_IP" ]; then
        if curl -s -f http://$SERVER_IP >/dev/null 2>&1; then
            print_success "Application responds correctly on external IP"
        else
            print_warning "External connectivity may be limited (check firewall)"
        fi
    fi
    
    print_success "Nginx configuration with default page fix completed"
    
    # Show final status
    echo ""
    echo "🌐 Your crypto airdrop application should now be accessible at:"
    if [ "$SERVER_IP" != "unknown" ]; then
        echo "   • http://$SERVER_IP"
    else
        echo "   • http://YOUR_SERVER_IP"
    fi
    
    echo ""
    echo "📋 If you still see the nginx default page:"
    echo "   1. Wait 2-3 minutes for all services to fully start"
    echo "   2. Clear browser cache (Ctrl+F5)"
    echo "   3. Try incognito/private browsing mode"
    echo "   4. Check app status: pm2 status"
}

# Start application
start_application() {
    print_status "Starting application with PM2..."
    
    cd $APP_DIR
    
    # Stop any existing PM2 processes
    pm2 delete all 2>/dev/null || true
    
    # Start application
    pm2 start ecosystem.config.cjs
    pm2 save
    
    # Configure PM2 startup
    print_status "Configuring PM2 auto-startup..."
    sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME
    
    # Verify application is running
    print_status "Verifying application startup..."
    sleep 10
    
    if pm2 list | grep -q "crypto-airdrop.*online"; then
        print_success "Application started successfully!"
    else
        print_error "Application failed to start. Checking logs..."
        pm2 logs crypto-airdrop --lines 20
        exit 1
    fi
}

# Configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    
    # Reset UFW and set defaults
    sudo ufw --force reset
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    
    # Allow necessary ports
    sudo ufw allow 22/tcp comment 'SSH'
    sudo ufw allow 80/tcp comment 'HTTP'
    sudo ufw allow 443/tcp comment 'HTTPS'
    
    # Enable firewall
    sudo ufw --force enable
    
    print_success "Firewall configured successfully"
}

# Create management script
create_management_script() {
    print_status "Creating management script..."
    
    cd $APP_DIR
    
    cat > manage.sh << 'SCRIPT'
#!/bin/bash
# Crypto Airdrop Platform Management Script

APP_NAME="crypto-airdrop"
APP_DIR="/opt/crypto-airdrop"

case "$1" in
    start)
        echo "Starting $APP_NAME..."
        pm2 start $APP_NAME
        ;;
    stop)
        echo "Stopping $APP_NAME..."
        pm2 stop $APP_NAME
        ;;
    restart)
        echo "Restarting $APP_NAME..."
        pm2 restart $APP_NAME
        ;;
    status)
        echo "Status of $APP_NAME:"
        pm2 status
        echo ""
        echo "Recent logs:"
        pm2 logs $APP_NAME --lines 10
        ;;
    logs)
        echo "Live logs for $APP_NAME:"
        pm2 logs $APP_NAME
        ;;
    update)
        echo "Updating $APP_NAME..."
        cd $APP_DIR
        git pull
        npm ci --production=false
        npm run db:push
        npm run build
        pm2 restart $APP_NAME
        echo "Update completed!"
        ;;
    backup)
        echo "Creating database backup..."
        mkdir -p /var/backups/crypto-airdrop
        BACKUP_FILE="/var/backups/crypto-airdrop/backup_$(date +%Y%m%d_%H%M%S).sql"
        pg_dump $DATABASE_URL > $BACKUP_FILE
        echo "Backup saved to: $BACKUP_FILE"
        ;;
    health)
        echo "Health check for $APP_NAME:"
        if pm2 list | grep -q "$APP_NAME.*online"; then
            echo "✅ Application is running"
        else
            echo "❌ Application is not running"
        fi
        
        if systemctl is-active --quiet postgresql; then
            echo "✅ PostgreSQL is running"
        else
            echo "❌ PostgreSQL is not running"
        fi
        
        if systemctl is-active --quiet nginx; then
            echo "✅ Nginx is running"
        else
            echo "❌ Nginx is not running"
        fi
        
        echo ""
        echo "System resources:"
        echo "Memory usage: $(free -h | awk '/^Mem:/ {print $3 "/" $2}')"
        echo "Disk usage: $(df -h / | awk '/\// {print $3 "/" $2 " (" $5 ")"}')"
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs|update|backup|health}"
        echo ""
        echo "Commands:"
        echo "  start   - Start the application"
        echo "  stop    - Stop the application"
        echo "  restart - Restart the application"
        echo "  status  - Show application status and recent logs"
        echo "  logs    - Show live logs"
        echo "  update  - Pull latest code and restart"
        echo "  backup  - Create database backup"
        echo "  health  - System health check"
        ;;
esac
SCRIPT

    chmod +x manage.sh
    
    print_success "Management script created at $APP_DIR/manage.sh"
}

# Setup automatic backups
setup_backups() {
    print_status "Setting up automatic backups..."
    
    # Create backup directory
    sudo mkdir -p /var/backups/crypto-airdrop
    sudo chown $USER:$USER /var/backups/crypto-airdrop
    
    # Add backup cron job (daily at 2 AM)
    (crontab -l 2>/dev/null | grep -v "crypto-airdrop backup"; echo "0 2 * * * $APP_DIR/manage.sh backup") | crontab -
    
    # Add cleanup cron job (weekly cleanup of old backups)
    (crontab -l 2>/dev/null | grep -v "crypto-airdrop cleanup"; echo "0 3 * * 0 find /var/backups/crypto-airdrop -name '*.sql' -mtime +30 -delete") | crontab -
    
    print_success "Automatic backups configured (daily at 2 AM, 30-day retention)"
}

# Display final information
display_final_info() {
    # Try multiple methods to get server IP
    local server_ip=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
                     curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
                     curl -s --connect-timeout 5 ipinfo.io/ip 2>/dev/null || \
                     hostname -I | awk '{print $1}' || \
                     ip route get 8.8.8.8 | awk '/src/ {print $7}' 2>/dev/null || \
                     echo "YOUR_SERVER_IP")
    
    # Create deployment info file
    cat > $APP_DIR/deployment-info.txt << INFO
Crypto Airdrop Platform Deployment Complete
==========================================
Date: $(date)
Server: http://$server_ip
Application Directory: $APP_DIR

Database Information:
- Database: $DB_NAME
- User: $DB_USER
- Password: $DB_PASSWORD

Default Admin Credentials:
- Check your seed file for default credentials

Management Commands:
- $APP_DIR/manage.sh status    # Check status
- $APP_DIR/manage.sh restart   # Restart app
- $APP_DIR/manage.sh logs      # View logs
- $APP_DIR/manage.sh update    # Update app
- $APP_DIR/manage.sh backup    # Backup database
- $APP_DIR/manage.sh health    # Health check

Service Management:
- PostgreSQL: sudo systemctl status postgresql
- Nginx: sudo systemctl status nginx
- PM2: pm2 status

Logs Location:
- Application: $APP_DIR/logs/
- Nginx: /var/log/nginx/
- PostgreSQL: /var/log/postgresql/

Security Notes:
- Firewall is enabled (UFW)
- Change default passwords after first login
- Consider setting up SSL/TLS for production

INFO

    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                     DEPLOYMENT COMPLETED SUCCESSFULLY!                      ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}Your Crypto Airdrop Platform is now live!${NC}"
    echo ""
    echo -e "${BLUE}Access your application:${NC}"
    echo "• Primary URL: http://$server_ip"
    echo "• Alternative: http://$server_ip:80"
    if [[ "$server_ip" != "YOUR_SERVER_IP" ]]; then
        echo "• Direct test: curl -I http://$server_ip"
    fi
    echo ""
    echo -e "${BLUE}Service Ports:${NC}"
    echo "• Nginx (HTTP): Port 80"
    echo "• Application: Port ${APP_PORT:-5000} (internal)"
    echo "• PostgreSQL: Port 5432 (local only)"
    echo ""
    echo -e "${BLUE}Connection Verification:${NC}"
    if netstat -tlnp 2>/dev/null | grep -q ":80 "; then
        echo "• Port 80: LISTENING (Nginx)"
    else
        echo "• Port 80: NOT LISTENING (Check Nginx)"
    fi
    
    # Check both common application ports
    if netstat -tlnp 2>/dev/null | grep -q ":5000 "; then
        echo "• Port 5000: LISTENING (Application)"
        APP_PORT="5000"
    elif netstat -tlnp 2>/dev/null | grep -q ":3000 "; then
        echo "• Port 3000: LISTENING (Application)"
        APP_PORT="3000"
    else
        echo "• Application ports (3000/5000): NOT LISTENING (Check PM2)"
        APP_PORT="5000"
    fi
    echo ""
    echo -e "${BLUE}Management Commands:${NC}"
    echo "• Status check: $APP_DIR/manage.sh status"
    echo "• View logs: $APP_DIR/manage.sh logs"
    echo "• Health check: ./health-check.sh"
    echo "• Port diagnostic: ./port-diagnostic.sh"
    echo "• Restart services: $APP_DIR/manage.sh restart"
    echo ""
    echo -e "${BLUE}Troubleshooting:${NC}"
    echo "• If no display on IP: Run ./port-diagnostic.sh for detailed analysis"
    echo "• Check firewall: sudo ufw status"
    echo "• Verify Nginx: sudo systemctl status nginx"
    echo "• Check application: pm2 status"
    echo "• Test connectivity: curl -I http://$server_ip"
    echo "• View deployment info: cat $APP_DIR/deployment-info.txt"
    echo ""
    echo -e "${GREEN}Deployment complete! Your crypto airdrop platform is running.${NC}"
}

# Main execution function
main() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    Crypto Airdrop Platform Deployment                       ║${NC}"
    echo -e "${BLUE}║                              One-Click Setup                                ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    print_status "Starting deployment process..."
    
    check_prerequisites
    install_system_dependencies
    setup_database
    setup_application
    configure_pm2
    configure_nginx
    start_application
    configure_firewall
    create_management_script
    setup_backups
    display_final_info
}

# Execute main function
main "$@"