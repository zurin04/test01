# Crypto Airdrop Platform - VPS Deployment Guide

## One-Click VPS Deployment

This guide provides a complete one-click deployment solution for your Crypto Airdrop Platform on any Ubuntu/Debian VPS.

## Prerequisites

### VPS Requirements
- **Operating System**: Ubuntu 20.04+ or Debian 11+
- **Memory**: Minimum 2GB RAM (4GB recommended)
- **Storage**: Minimum 20GB SSD
- **Network**: Public IP address with ports 22, 80, 443 accessible

### Supported VPS Providers
- DigitalOcean
- Linode  
- Vultr
- AWS EC2
- Google Cloud Platform
- Microsoft Azure
- Any Ubuntu/Debian VPS

### Local Requirements
- SSH access to your VPS
- Git installed on your local machine

## Quick Deployment

### 1. Prepare Your VPS
```bash
# Connect to your VPS
ssh root@YOUR_SERVER_IP

# Create a non-root user (if not exists)
adduser deploy
usermod -aG sudo deploy
su - deploy
```

### 2. Clone and Deploy
```bash
# Clone the repository
git clone https://github.com/yourusername/crypto-airdrop-platform.git
cd crypto-airdrop-platform

# Run one-click deployment
sudo ./deploy.sh
```

That's it! The script will automatically:
- Install all system dependencies (Node.js 20, PostgreSQL, Nginx, PM2)
- Create and configure the database
- Build and deploy the application
- Configure reverse proxy and security
- Set up automatic backups
- Create management tools

## Post-Deployment

### Access Your Application
After deployment completes, your application will be available at:
```
http://YOUR_SERVER_IP
```

### Default Credentials
Check the `deployment-info.txt` file created in your application directory for:
- Database credentials
- Application access information
- Management commands

### Management Commands
The deployment creates a management script at `/var/www/crypto-airdrop/manage.sh`:

```bash
# Check application status
./manage.sh status

# View live logs
./manage.sh logs

# Restart application
./manage.sh restart

# Create database backup
./manage.sh backup

# Update application
./manage.sh update

# Health check
./manage.sh health
```

## SSL/HTTPS Setup (Optional)

### Using Certbot (Recommended)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com

# Test automatic renewal
sudo certbot renew --dry-run
```

### Manual SSL Setup
If you have your own SSL certificates:
```bash
# Copy certificates to appropriate location
sudo cp your-certificate.crt /etc/ssl/certs/
sudo cp your-private-key.key /etc/ssl/private/

# Update Nginx configuration
sudo nano /etc/nginx/sites-available/crypto-airdrop
# Add SSL configuration

# Reload Nginx
sudo systemctl reload nginx
```

## Monitoring and Maintenance

### Service Status
```bash
# Check all services
sudo systemctl status postgresql nginx
pm2 status

# View system resources
htop
df -h
free -h
```

### Log Locations
- **Application Logs**: `/var/www/crypto-airdrop/logs/`
- **Nginx Logs**: `/var/log/nginx/`
- **PostgreSQL Logs**: `/var/log/postgresql/`
- **System Logs**: `/var/log/syslog`

### Backup Management
- **Automatic Backups**: Daily at 2 AM (30-day retention)
- **Manual Backup**: `./manage.sh backup`
- **Backup Location**: `/var/backups/crypto-airdrop/`

### Updates
```bash
# Update application
cd /var/www/crypto-airdrop
./manage.sh update

# Update system packages
sudo apt update && sudo apt upgrade
```

## Security Features

### Firewall Configuration
The deployment automatically configures UFW firewall:
- Port 22 (SSH): Allowed
- Port 80 (HTTP): Allowed  
- Port 443 (HTTPS): Allowed
- All other ports: Denied

### Nginx Security Headers
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- X-XSS-Protection: enabled
- Referrer-Policy: strict-origin-when-cross-origin

### Rate Limiting
- API endpoints: 10 requests/second
- Upload endpoints: 1 request/second
- Burst allowance configured

## Troubleshooting

### Application Won't Start
```bash
# Check PM2 status
pm2 status
pm2 logs crypto-airdrop

# Check database connection
sudo -u postgres psql -c "\l"

# Restart services
./manage.sh restart
sudo systemctl restart postgresql nginx
```

### Database Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Connect to database
sudo -u postgres psql

# Check database logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### Nginx Issues
```bash
# Test Nginx configuration
sudo nginx -t

# Check Nginx status
sudo systemctl status nginx

# Reload configuration
sudo systemctl reload nginx
```

### Port Issues
```bash
# Check which process is using a port
sudo netstat -tlnp | grep :5000
sudo ss -tlnp | grep :5000

# Check firewall status
sudo ufw status
```

### Common Solutions

#### Reset Everything
```bash
# Stop all services
pm2 delete all
sudo systemctl stop nginx postgresql

# Clean up
sudo rm -rf /var/www/crypto-airdrop
sudo dropdb crypto_airdrop_db
sudo dropuser crypto_user

# Redeploy
./deploy.sh
```

#### Database Connection Error
```bash
# Check DATABASE_URL in environment
cat /var/www/crypto-airdrop/.env

# Test database connection
psql "postgresql://crypto_user:PASSWORD@localhost:5432/crypto_airdrop_db" -c "\dt"
```

#### Permission Issues
```bash
# Fix file permissions
sudo chown -R deploy:deploy /var/www/crypto-airdrop
chmod -R 755 /var/www/crypto-airdrop
```

## Performance Optimization

### For Higher Traffic
```bash
# Increase PM2 instances
pm2 scale crypto-airdrop 4

# Configure PostgreSQL for performance
sudo nano /etc/postgresql/*/main/postgresql.conf
# Adjust shared_buffers, work_mem, max_connections

# Configure Nginx worker processes
sudo nano /etc/nginx/nginx.conf
# Set worker_processes to number of CPU cores
```

### Resource Monitoring
```bash
# Monitor resource usage
htop
iotop
nethogs

# Check application performance
pm2 monit
```

## Support

### Log Collection for Debugging
```bash
# Collect all relevant logs
./manage.sh health > debug-info.txt
pm2 logs crypto-airdrop --lines 100 >> debug-info.txt
sudo tail -100 /var/log/nginx/error.log >> debug-info.txt
```

### Getting Help
1. Check this deployment guide
2. Review application logs
3. Check system logs
4. Search existing issues
5. Create detailed bug report with logs

## Environment Variables

The deployment script automatically generates secure environment variables:

```bash
DATABASE_URL=postgresql://crypto_user:SECURE_PASSWORD@localhost:5432/crypto_airdrop_db
SESSION_SECRET=SECURE_64_CHAR_HEX
NODE_ENV=production
PORT=5000
CORS_ORIGIN=http://localhost:5000
```

All passwords and secrets are automatically generated using OpenSSL for maximum security.

## Architecture Overview

```
Internet → Nginx (Port 80/443) → Node.js App (Port 5000) → PostgreSQL (Port 5432)
                ↓
         Static Files, Rate Limiting,
         Security Headers, SSL
```

Your crypto airdrop platform is now production-ready with enterprise-grade security, monitoring, and management tools!