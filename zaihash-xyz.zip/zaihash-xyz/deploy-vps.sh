#!/bin/bash

# Crypto Airdrop Platform - Production VPS Deployment
# Single-script automated deployment for Ubuntu/Debian VPS

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Logging functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Configuration
APP_NAME="crypto-airdrop"
APP_DIR="/var/www/${APP_NAME}"
NODE_VERSION="20"
APP_PORT="5000"

# Generated variables (will be set during deployment)
DB_NAME="crypto_airdrop_prod"
DB_USER="crypto_app"
DB_PASSWORD=""
SESSION_SECRET=""
SERVER_IP=""

print_header() {
    echo ""
    echo -e "${PURPLE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║          Crypto Airdrop Platform - VPS Deployment           ║${NC}"
    echo -e "${PURPLE}║                  Production Ready Setup                     ║${NC}"
    echo -e "${PURPLE}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Check if running as root (should not be)
check_user() {
    if [[ $EUID -eq 0 ]]; then
        log_error "Do not run this script as root. Use a user with sudo privileges."
        exit 1
    fi
    
    if ! sudo -n true 2>/dev/null; then
        log_error "This script requires sudo privileges. Please run with a user that has sudo access."
        exit 1
    fi
}

# Check OS compatibility
check_os() {
    if ! grep -qE "(Ubuntu|Debian)" /etc/os-release; then
        log_warning "This script is optimized for Ubuntu/Debian. Proceeding anyway..."
        sleep 3
    fi
    log_info "OS check completed"
}

# Update system packages
update_system() {
    log_info "Updating system packages..."
    sudo apt update -y > /dev/null 2>&1
    sudo apt upgrade -y > /dev/null 2>&1
    log_success "System updated"
}

# Install system dependencies
install_dependencies() {
    log_info "Installing system dependencies..."
    
    # Essential packages
    sudo apt install -y curl wget gnupg2 software-properties-common \
        postgresql postgresql-contrib nginx ufw openssl \
        git unzip build-essential > /dev/null 2>&1
    
    # Install Node.js 20
    if ! command -v node &>/dev/null || [[ $(node -v | cut -d'v' -f2 | cut -d'.' -f1) -lt 20 ]]; then
        log_info "Installing Node.js ${NODE_VERSION}..."
        curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | sudo -E bash - > /dev/null 2>&1
        sudo apt install -y nodejs > /dev/null 2>&1
    fi
    
    # Install PM2
    if ! command -v pm2 &>/dev/null; then
        log_info "Installing PM2..."
        sudo npm install -g pm2 > /dev/null 2>&1
    fi
    
    # Start services
    sudo systemctl enable --now postgresql nginx > /dev/null 2>&1
    
    log_success "Dependencies installed (Node.js $(node -v), PM2 $(pm2 -v))"
}

# Setup PostgreSQL database
setup_database() {
    log_info "Setting up PostgreSQL database..."
    
    # Generate secure credentials
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    
    # Create database and user
    sudo -u postgres psql > /dev/null 2>&1 << EOF
DROP DATABASE IF EXISTS ${DB_NAME};
DROP USER IF EXISTS ${DB_USER};
CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';
ALTER USER ${DB_USER} CREATEDB;
CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};
GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
\q
EOF
    
    log_success "Database created (${DB_NAME})"
}

# Setup application
setup_application() {
    log_info "Setting up application..."
    
    # Create app directory
    sudo mkdir -p ${APP_DIR}
    sudo chown $USER:$USER ${APP_DIR}
    
    # Copy application files
    cp -r . ${APP_DIR}/
    cd ${APP_DIR}
    
    # Generate session secret
    SESSION_SECRET=$(openssl rand -hex 64)
    
    # Create environment file
    cat > .env << EOF
NODE_ENV=production
PORT=${APP_PORT}
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
SESSION_SECRET=${SESSION_SECRET}
CORS_ORIGIN=http://localhost:${APP_PORT}
EOF
    
    # Install dependencies
    log_info "Installing application dependencies..."
    npm ci --only=production > /dev/null 2>&1
    
    # Build application
    log_info "Building application..."
    if ! npm run build > /dev/null 2>&1; then
        log_error "Build failed. Check package.json scripts."
        exit 1
    fi
    
    # Verify build output
    if [[ ! -f "dist/index.js" ]]; then
        log_error "Build output not found. Build may have failed."
        exit 1
    fi
    
    log_success "Application built successfully"
}

# Initialize database schema
init_database() {
    log_info "Initializing database schema..."
    
    # Set environment variables for database operations
    export NODE_ENV=production
    export DATABASE_URL="postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}"
    export SESSION_SECRET="${SESSION_SECRET}"
    
    # Push schema
    if ! npm run db:push > /dev/null 2>&1; then
        log_error "Database schema initialization failed"
        exit 1
    fi
    
    # Seed database
    log_info "Seeding database..."
    npm run db:seed > /dev/null 2>&1 || log_warning "Database seeding failed (continuing anyway)"
    
    log_success "Database initialized"
}

# Configure PM2
setup_pm2() {
    log_info "Configuring PM2..."
    
    cd ${APP_DIR}
    
    # Create PM2 ecosystem file
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: '${APP_NAME}',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: ${APP_PORT},
      DATABASE_URL: 'postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}',
      SESSION_SECRET: '${SESSION_SECRET}'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF
    
    # Create logs directory
    mkdir -p logs
    
    log_success "PM2 configured"
}

# Configure Nginx
setup_nginx() {
    log_info "Configuring Nginx..."
    
    # Remove default sites
    sudo rm -f /etc/nginx/sites-enabled/default
    sudo rm -f /etc/nginx/sites-available/default
    
    # Create site configuration
    sudo tee /etc/nginx/sites-available/${APP_NAME} > /dev/null << EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    
    client_max_body_size 100M;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=login:10m rate=5r/m;
    
    location / {
        proxy_pass http://localhost:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:${APP_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /api/auth/ {
        limit_req zone=login burst=5 nodelay;
        proxy_pass http://localhost:${APP_PORT};
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
    
    # Enable site
    sudo ln -sf /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/
    
    # Test configuration
    if ! sudo nginx -t > /dev/null 2>&1; then
        log_error "Nginx configuration test failed"
        exit 1
    fi
    
    # Restart Nginx
    sudo systemctl restart nginx
    
    log_success "Nginx configured and restarted"
}

# Configure firewall
setup_firewall() {
    log_info "Configuring firewall..."
    
    # Reset and configure UFW
    sudo ufw --force reset > /dev/null 2>&1
    sudo ufw default deny incoming > /dev/null 2>&1
    sudo ufw default allow outgoing > /dev/null 2>&1
    
    # Allow essential ports
    sudo ufw allow 22/tcp comment 'SSH' > /dev/null 2>&1
    sudo ufw allow 80/tcp comment 'HTTP' > /dev/null 2>&1
    sudo ufw allow 443/tcp comment 'HTTPS' > /dev/null 2>&1
    
    # Enable firewall
    sudo ufw --force enable > /dev/null 2>&1
    
    log_success "Firewall configured"
}

# Start application
start_application() {
    log_info "Starting application..."
    
    cd ${APP_DIR}
    
    # Stop any existing PM2 processes
    pm2 delete all > /dev/null 2>&1 || true
    
    # Start application
    pm2 start ecosystem.config.js > /dev/null 2>&1
    pm2 save > /dev/null 2>&1
    
    # Configure PM2 startup
    sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME > /dev/null 2>&1 || true
    
    # Wait and verify
    sleep 5
    if pm2 list | grep -q "${APP_NAME}.*online"; then
        log_success "Application started successfully"
    else
        log_error "Application failed to start"
        pm2 logs ${APP_NAME} --lines 10
        exit 1
    fi
}

# Create management script
create_management_tools() {
    log_info "Creating management tools..."
    
    cd ${APP_DIR}
    
    # Create management script
    cat > manage.sh << 'SCRIPT'
#!/bin/bash

APP_NAME="crypto-airdrop"
APP_DIR="/var/www/crypto-airdrop"

case "$1" in
    start)
        echo "Starting application..."
        pm2 start ${APP_NAME}
        ;;
    stop)
        echo "Stopping application..."
        pm2 stop ${APP_NAME}
        ;;
    restart)
        echo "Restarting application..."
        pm2 restart ${APP_NAME}
        ;;
    status)
        echo "Application Status:"
        pm2 status
        echo ""
        echo "Recent logs:"
        pm2 logs ${APP_NAME} --lines 20
        ;;
    logs)
        echo "Live logs:"
        pm2 logs ${APP_NAME}
        ;;
    update)
        echo "Updating application..."
        cd ${APP_DIR}
        git pull
        npm ci --only=production
        npm run build
        pm2 restart ${APP_NAME}
        echo "Update complete!"
        ;;
    backup)
        echo "Creating database backup..."
        source .env
        mkdir -p ./backups
        pg_dump ${DATABASE_URL} > "./backups/backup_$(date +%Y%m%d_%H%M%S).sql"
        echo "Backup created in ./backups/"
        ;;
    health)
        echo "=== System Health Check ==="
        
        # Check services
        if pm2 list | grep -q "${APP_NAME}.*online"; then
            echo "✅ Application: Running"
        else
            echo "❌ Application: Not running"
        fi
        
        if systemctl is-active --quiet postgresql; then
            echo "✅ PostgreSQL: Running"
        else
            echo "❌ PostgreSQL: Not running"
        fi
        
        if systemctl is-active --quiet nginx; then
            echo "✅ Nginx: Running"
        else
            echo "❌ Nginx: Not running"
        fi
        
        # Check connectivity
        if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200\|302"; then
            echo "✅ HTTP: Responding"
        else
            echo "❌ HTTP: Not responding"
        fi
        
        # System resources
        echo ""
        echo "=== System Resources ==="
        echo "Memory: $(free -h | awk '/^Mem:/ {printf "%s/%s (%.1f%%)", $3, $2, $3/$2*100}')"
        echo "Disk: $(df -h / | awk '/\// {printf "%s/%s (%s)", $3, $2, $5}')"
        echo "Load: $(uptime | awk -F'load average:' '{print $2}')"
        ;;
    *)
        echo "Crypto Airdrop Platform Management"
        echo ""
        echo "Usage: $0 {start|stop|restart|status|logs|update|backup|health}"
        echo ""
        echo "Commands:"
        echo "  start   - Start the application"
        echo "  stop    - Stop the application" 
        echo "  restart - Restart the application"
        echo "  status  - Show status and recent logs"
        echo "  logs    - Show live logs"
        echo "  update  - Pull latest code and restart"
        echo "  backup  - Create database backup"
        echo "  health  - Complete system health check"
        ;;
esac
SCRIPT
    
    chmod +x manage.sh
    
    # Create daily backup cron job
    (crontab -l 2>/dev/null | grep -v "${APP_NAME} backup"; echo "0 2 * * * ${APP_DIR}/manage.sh backup") | crontab -
    
    log_success "Management tools created"
}

# Get server IP
get_server_ip() {
    SERVER_IP=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || \
               curl -s --connect-timeout 5 icanhazip.com 2>/dev/null || \
               ip route get 8.8.8.8 2>/dev/null | awk '/src/ {print $7}' || \
               echo "UNKNOWN")
}

# Display final information
show_deployment_info() {
    get_server_ip
    
    # Create deployment info file
    cat > ${APP_DIR}/deployment-info.txt << INFO
Crypto Airdrop Platform - Production Deployment
=============================================
Deployed: $(date)
Server IP: ${SERVER_IP}
Application URL: http://${SERVER_IP}

Database Information:
- Name: ${DB_NAME}
- User: ${DB_USER}
- Password: ${DB_PASSWORD}
- URL: postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}

Application Details:
- Directory: ${APP_DIR}
- Port: ${APP_PORT}
- Environment: production
- Process Manager: PM2

Management:
- Status: ${APP_DIR}/manage.sh status
- Logs: ${APP_DIR}/manage.sh logs
- Restart: ${APP_DIR}/manage.sh restart
- Health Check: ${APP_DIR}/manage.sh health
- Backup: ${APP_DIR}/manage.sh backup

Services:
- Application: pm2 status
- Database: sudo systemctl status postgresql
- Web Server: sudo systemctl status nginx
- Firewall: sudo ufw status

Security Notes:
- Change default credentials after first login
- Consider setting up SSL/TLS with Certbot
- Monitor logs regularly for security issues
- Keep system packages updated

INFO
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              DEPLOYMENT COMPLETED SUCCESSFULLY!             ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}🚀 Your Crypto Airdrop Platform is now live!${NC}"
    echo ""
    echo -e "${YELLOW}Access your application:${NC}"
    echo "   🌐 http://${SERVER_IP}"
    echo ""
    echo -e "${YELLOW}Management commands:${NC}"
    echo "   📊 ${APP_DIR}/manage.sh status    # Check status"
    echo "   📝 ${APP_DIR}/manage.sh logs      # View logs" 
    echo "   🔄 ${APP_DIR}/manage.sh restart   # Restart app"
    echo "   🏥 ${APP_DIR}/manage.sh health    # Health check"
    echo "   💾 ${APP_DIR}/manage.sh backup    # Create backup"
    echo ""
    echo -e "${YELLOW}Service status:${NC}"
    if systemctl is-active --quiet nginx; then
        echo "   ✅ Nginx (Port 80)"
    else
        echo "   ❌ Nginx (Port 80)"
    fi
    
    if pm2 list | grep -q "${APP_NAME}.*online"; then
        echo "   ✅ Application (Port ${APP_PORT})"
    else
        echo "   ❌ Application (Port ${APP_PORT})"
    fi
    
    if systemctl is-active --quiet postgresql; then
        echo "   ✅ PostgreSQL"
    else
        echo "   ❌ PostgreSQL" 
    fi
    echo ""
    echo -e "${YELLOW}Next steps:${NC}"
    echo "   1. Test your application: curl -I http://${SERVER_IP}"
    echo "   2. Set up SSL with Certbot (recommended for production)"
    echo "   3. Configure your domain name (if applicable)"
    echo "   4. Review and update default admin credentials"
    echo ""
    echo -e "${BLUE}📋 Full deployment details saved to: ${APP_DIR}/deployment-info.txt${NC}"
    echo ""
}

# Main deployment function
main() {
    print_header
    
    log_info "Starting VPS deployment..."
    
    check_user
    check_os
    update_system
    install_dependencies
    setup_database
    setup_application
    init_database
    setup_pm2
    setup_nginx
    setup_firewall
    start_application
    create_management_tools
    show_deployment_info
    
    log_success "Deployment completed successfully!"
}

# Run main deployment
main "$@"