import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Loader2, Image as ImageIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { SiteSettings } from "@shared/schema";
import { ImageUploader } from "@/components/ui/image-uploader";

const siteSettingsSchema = z.object({
  site_name: z.string().min(1, "Site name is required"),
  site_description: z.string().optional(),
  logo_url: z.string().optional().nullable(),
  banner_url: z.string().optional().nullable(),
  twitter_link: z.string().url("Please enter a valid URL").optional().nullable().or(z.literal("")),
  discord_link: z.string().url("Please enter a valid URL").optional().nullable().or(z.literal("")),
  telegram_link: z.string().url("Please enter a valid URL").optional().nullable().or(z.literal("")),
  creator_fee_amount: z.string().optional().nullable().or(z.literal("")),
  creator_fee_currency: z.string().optional().nullable().or(z.literal("")),
  creator_payment_address: z.string().optional().nullable().or(z.literal("")),
  creator_payment_network: z.string().optional().nullable().or(z.literal("")),
});

type SiteSettingsFormValues = z.infer<typeof siteSettingsSchema>;

export default function SiteSettingsForm() {
  const { toast } = useToast();
  
  const { data: settings, isLoading } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });
  
  const form = useForm<SiteSettingsFormValues>({
    resolver: zodResolver(siteSettingsSchema),
    defaultValues: {
      site_name: "",
      site_description: "",
      logo_url: "",
      banner_url: "",
      twitter_link: "",
      discord_link: "",
      telegram_link: "",
      creator_fee_amount: "",
      creator_fee_currency: "",
      creator_payment_address: "",
      creator_payment_network: ""
    }
  });
  
  useEffect(() => {
    if (settings) {
      form.reset({
        site_name: settings.site_name,
        site_description: settings.site_description || "",
        logo_url: settings.logo_url || "",
        banner_url: settings.banner_url || "",
        twitter_link: settings.twitter_link || "",
        discord_link: settings.discord_link || "",
        telegram_link: settings.telegram_link || "",
        creator_fee_amount: settings.creator_fee_amount || "",
        creator_fee_currency: settings.creator_fee_currency || "",
        creator_payment_address: settings.creator_payment_address || "",
        creator_payment_network: settings.creator_payment_network || ""
      });
    }
  }, [settings, form]);
  
  // State to track logo and banner URLs (separate from form state)
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [bannerUrl, setBannerUrl] = useState<string | null>(null);

  // Update logo and banner URLs when settings load
  useEffect(() => {
    if (settings) {
      setLogoUrl(settings.logo_url);
      setBannerUrl(settings.banner_url);
    }
  }, [settings]);

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: SiteSettingsFormValues) => {
      // Include the latest logo and banner URLs from state
      const updatedData = {
        ...data,
        logo_url: logoUrl,
        banner_url: bannerUrl
      };
      const response = await apiRequest("PUT", "/api/admin/site-settings", updatedData);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "The site settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/site-settings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: SiteSettingsFormValues) => {
    updateSettingsMutation.mutate(values);
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">General Information</h3>
            
            <FormField
              control={form.control}
              name="site_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Site Name</FormLabel>
                  <FormControl>
                    <Input placeholder="My Crypto Airdrop Site" {...field} />
                  </FormControl>
                  <FormDescription>
                    The name of your website that appears in the header and title
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="site_description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Site Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Discover and track crypto airdrops, tasks, and rewards" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    A brief description that appears in search results and social shares
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Appearance</h3>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Site Logo</label>
              <ImageUploader
                onImageUploaded={(url) => {
                  setLogoUrl(url);
                  toast({
                    title: "Logo updated",
                    description: "Your site logo has been updated. Save settings to apply changes.",
                  });
                }}
                currentImageUrl={logoUrl}
                endpoint="/api/admin/upload/site-logo"
                imageType="logo"
                label="Site Logo"
                buttonText="Upload Logo"
                className="p-4 border border-dashed rounded-lg border-muted-foreground/50 bg-muted/20"
              />
              <p className="text-sm text-muted-foreground">
                Upload your site logo (recommended size: 160x40px)
              </p>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Site Banner</label>
              <ImageUploader
                onImageUploaded={(url) => {
                  setBannerUrl(url);
                  toast({
                    title: "Banner updated",
                    description: "Your site banner has been updated. Save settings to apply changes.",
                  });
                }}
                currentImageUrl={bannerUrl}
                endpoint="/api/admin/upload/site-banner"
                imageType="banner"
                label="Site Banner"
                buttonText="Upload Banner"
                className="p-4 border border-dashed rounded-lg border-muted-foreground/50 bg-muted/20"
              />
              <p className="text-sm text-muted-foreground">
                Upload your homepage banner image (recommended size: 1200x400px)
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Social Media</h3>
            
            <FormField
              control={form.control}
              name="twitter_link"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Twitter URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://twitter.com/yourusername" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormDescription>
                    Your Twitter profile URL
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="discord_link"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Discord URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://discord.gg/yourinvite" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormDescription>
                    Your Discord server invite URL
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="telegram_link"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Telegram URL</FormLabel>
                  <FormControl>
                    <Input placeholder="https://t.me/yourchannel" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormDescription>
                    Your Telegram channel or group URL
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Creator Payment Settings</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Configure payment details for creator verification. Users will send cryptocurrency to become verified creators.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="creator_fee_amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Amount</FormLabel>
                    <FormControl>
                      <Input placeholder="0.05" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      Amount required for creator verification
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="creator_fee_currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Currency</FormLabel>
                    <FormControl>
                      <Input placeholder="ETH" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      Currency symbol (e.g., ETH, BNB, MATIC)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="creator_payment_address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Wallet Address</FormLabel>
                  <FormControl>
                    <Input placeholder="0x..." {...field} value={field.value || ""} className="font-mono text-xs md:text-sm" />
                  </FormControl>
                  <FormDescription>
                    Your wallet address where creators will send payment
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="creator_payment_network"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Network</FormLabel>
                  <FormControl>
                    <Input placeholder="Ethereum Mainnet" {...field} value={field.value || ""} />
                  </FormControl>
                  <FormDescription>
                    Blockchain network for payments (e.g., Ethereum Mainnet, Binance Smart Chain, Polygon)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full md:w-auto"
            disabled={updateSettingsMutation.isPending}
          >
            {updateSettingsMutation.isPending && (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            )}
            Save Settings
          </Button>
        </form>
      </Form>
    </div>
  );
}