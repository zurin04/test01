import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ImageUploader } from '@/components/ui/image-uploader';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, X, Image as ImageIcon, FileText, ArrowUp, ArrowDown } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface AirdropStep {
  content: string;
  imageUrl?: string;
  imageUrls?: string[]; // Support for multiple images per step
}

interface AirdropStepEditorProps {
  steps: AirdropStep[];
  onChange: (steps: AirdropStep[]) => void;
  className?: string;
  endpoint?: string;
}

export function AirdropStepEditor({ steps, onChange, className, endpoint }: AirdropStepEditorProps) {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  const addStep = () => {
    const newSteps = [...steps, { content: '', imageUrl: undefined, imageUrls: [] }];
    onChange(newSteps);
    // Set the new step as active for editing
    setActiveStep(newSteps.length - 1);
  };

  const removeStep = (index: number) => {
    const newSteps = [...steps];
    newSteps.splice(index, 1);
    onChange(newSteps);
    // Reset active step if the active one was removed
    if (activeStep === index) {
      setActiveStep(null);
    } else if (activeStep !== null && activeStep > index) {
      // Adjust active step index if a step before it was removed
      setActiveStep(activeStep - 1);
    }
  };

  const updateStepContent = (index: number, content: string) => {
    const newSteps = [...steps];
    newSteps[index] = { ...newSteps[index], content };
    onChange(newSteps);
  };

  const updateStepImage = (index: number, imageUrl: string) => {
    const newSteps = [...steps];
    // If imageUrls doesn't exist yet, initialize it
    if (!newSteps[index].imageUrls) {
      newSteps[index].imageUrls = [];
    }
    // Add the new image URL to the imageUrls array
    newSteps[index] = { 
      ...newSteps[index], 
      imageUrl, // Keep for backward compatibility
      imageUrls: [...(newSteps[index].imageUrls || []), imageUrl] 
    };
    onChange(newSteps);
  };
  
  const removeStepImage = (stepIndex: number, imageIndex: number) => {
    const newSteps = [...steps];
    const imageUrls = [...(newSteps[stepIndex].imageUrls || [])];
    // Remove the image at the specified index
    imageUrls.splice(imageIndex, 1);
    
    // Update the step with modified imageUrls
    newSteps[stepIndex] = { 
      ...newSteps[stepIndex], 
      imageUrls,
      // Update imageUrl for backward compatibility
      imageUrl: imageUrls.length > 0 ? imageUrls[0] : undefined
    };
    onChange(newSteps);
  };

  const moveStep = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) || 
      (direction === 'down' && index === steps.length - 1)
    ) {
      return;
    }

    const newSteps = [...steps];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    const temp = newSteps[index];
    newSteps[index] = newSteps[newIndex];
    newSteps[newIndex] = temp;
    onChange(newSteps);

    // Adjust active step if it was moved
    if (activeStep === index) {
      setActiveStep(newIndex);
    } else if (activeStep === newIndex) {
      setActiveStep(index);
    }
  };

  const toggleStepEdit = (index: number) => {
    setActiveStep(activeStep === index ? null : index);
  };

  // Converting steps array to HTML with proper formatting for airdrop description
  const formatStepsToHTML = () => {
    const htmlSteps = steps.map((step, index) => {
      let stepHtml = `<div class="step">
<h3>Step ${index + 1}</h3>
<p>${step.content}</p>`;
      
      // First handle legacy single image
      if (step.imageUrl) {
        stepHtml += `\n<img src="${step.imageUrl}" alt="Step ${index + 1}" />`;
      }
      
      // Then handle multiple images if present
      if (step.imageUrls && step.imageUrls.length > 0) {
        step.imageUrls.forEach((imgUrl, imgIndex) => {
          // Skip the first image if it's already added through imageUrl
          if (imgIndex === 0 && imgUrl === step.imageUrl) return;
          stepHtml += `\n<img src="${imgUrl}" alt="Step ${index + 1} Image ${imgIndex + 1}" />`;
        });
      }
      
      stepHtml += '\n</div>';
      return stepHtml;
    });

    return htmlSteps.join('\n\n');
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div className="flex items-center justify-between mb-2">
        <Label className="text-base font-medium">Tutorial Steps</Label>
        <Button 
          type="button" 
          variant="outline" 
          size="sm" 
          onClick={addStep}
          className="flex items-center space-x-1"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Step
        </Button>
      </div>

      {steps.length === 0 ? (
        <div className="border border-dashed border-border rounded-md p-6 text-center">
          <FileText className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
          <p className="text-muted-foreground">No steps yet. Add your first tutorial step.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {steps.map((step, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-0">
                <div 
                  className={cn(
                    "p-3 cursor-pointer flex items-center justify-between bg-card hover:bg-accent/40 transition-colors", 
                    activeStep === index && "bg-accent/40"
                  )}
                  onClick={() => toggleStepEdit(index)}
                >
                  <div className="flex items-center">
                    <span className="font-medium">Step {index + 1}</span>
                    {((step.imageUrls && step.imageUrls.length > 0) || step.imageUrl) && (
                      <div className="flex items-center ml-2 text-muted-foreground">
                        <ImageIcon className="h-4 w-4 mr-1" />
                        <span className="text-xs">
                          {step.imageUrls?.length || (step.imageUrl ? 1 : 0)}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm" 
                      onClick={(e) => { 
                        e.stopPropagation();
                        moveStep(index, 'up');
                      }}
                      disabled={index === 0}
                      className="h-7 w-7 p-0 rounded-full"
                    >
                      <ArrowUp className="h-4 w-4" />
                      <span className="sr-only">Move up</span>
                    </Button>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm" 
                      onClick={(e) => { 
                        e.stopPropagation();
                        moveStep(index, 'down');
                      }}
                      disabled={index === steps.length - 1}
                      className="h-7 w-7 p-0 rounded-full"
                    >
                      <ArrowDown className="h-4 w-4" />
                      <span className="sr-only">Move down</span>
                    </Button>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm" 
                      onClick={(e) => { 
                        e.stopPropagation();
                        removeStep(index);
                      }}
                      className="h-7 w-7 p-0 rounded-full text-destructive hover:bg-destructive/10"
                    >
                      <X className="h-4 w-4" />
                      <span className="sr-only">Remove</span>
                    </Button>
                  </div>
                </div>

                {activeStep === index && (
                  <div className="p-4 border-t border-border">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor={`step-${index}-content`} className="mb-2 block">
                          Step Description
                        </Label>
                        <Textarea 
                          id={`step-${index}-content`}
                          value={step.content}
                          onChange={(e) => updateStepContent(index, e.target.value)}
                          placeholder="Describe what to do in this step..."
                          rows={4}
                        />
                      </div>

                      <div>
                        <Label className="mb-2 block">
                          Step Images (Optional)
                        </Label>
                        <div className="space-y-3">
                          {/* Image uploader for adding new images */}
                          <ImageUploader
                            onImageUploaded={(imageUrl) => updateStepImage(index, imageUrl)}
                            currentImageUrl={undefined}
                            endpoint={endpoint || "/api/admin/upload/airdrop-image"}
                            label=""
                            buttonText="Add Image to Step"
                          />
                          
                          {/* Display existing images with delete buttons */}
                          {step.imageUrls && step.imageUrls.length > 0 ? (
                            <div className="grid grid-cols-2 gap-2 mt-2">
                              {step.imageUrls.map((imgUrl, imgIndex) => (
                                <div key={imgIndex} className="relative group border rounded-md overflow-hidden">
                                  <img 
                                    src={imgUrl} 
                                    alt={`Step ${index + 1} Image ${imgIndex + 1}`}
                                    className="w-full h-24 object-cover"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => removeStepImage(index, imgIndex)}
                                    className="absolute top-1 right-1 bg-black/70 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    <X className="h-4 w-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">No images added yet.</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <input
        type="hidden"
        name="formattedDescription"
        value={formatStepsToHTML()}
      />
    </div>
  );
}