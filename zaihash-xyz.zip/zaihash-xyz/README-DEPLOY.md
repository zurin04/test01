# VPS Deployment Guide

## Quick Start

Deploy your Crypto Airdrop Platform to any Ubuntu/Debian VPS with a single command:

```bash
# Make the script executable
chmod +x deploy.sh

# Deploy (replace with your repository URL if needed)
./deploy.sh [repository_url] [domain_name]
```

## Examples

```bash
# Deploy from current directory
./deploy.sh

# Deploy from GitHub repository
./deploy.sh https://github.com/yourusername/crypto-airdrop.git

# Deploy with custom domain
./deploy.sh https://github.com/yourusername/crypto-airdrop.git yourdomain.com
```

## Requirements

- Ubuntu 20.04+ or Debian 11+ VPS
- 1GB+ RAM (2GB+ recommended)
- 20GB+ disk space
- Root or sudo access
- Internet connection

## What the Script Does

✅ **System Setup**
- Updates system packages
- Installs Node.js 20, PostgreSQL, Nginx, PM2
- Configures firewall (UFW)

✅ **Database Setup**
- Creates PostgreSQL database and user
- Generates secure passwords
- Initializes schema and seed data

✅ **Application Setup**
- Clones/copies your application
- Installs dependencies
- Builds production version
- Configures environment variables

✅ **Service Configuration**
- Sets up PM2 process manager
- Configures Nginx reverse proxy
- Sets up SSL-ready configuration
- Enables automatic startup

✅ **Management Tools**
- Creates comprehensive management script
- Sets up automated backups
- Configures health monitoring

## After Deployment

### Access Your Application
- Your app will be available at: `http://YOUR_SERVER_IP`
- Default admin login will be displayed after deployment

### Management Commands
```bash
cd /var/www/crypto-airdrop

# Check status
./manage.sh status

# View logs
./manage.sh logs

# Restart application
./manage.sh restart

# Health check
./manage.sh health

# Create backup
./manage.sh backup

# Fix common issues
./manage.sh fix
```

### Set Up SSL (Recommended)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com

# Auto-renewal is configured automatically
```

## Troubleshooting

### Application Not Starting
```bash
# Check PM2 status
pm2 status

# Check logs
pm2 logs crypto-airdrop

# Restart application
cd /var/www/crypto-airdrop
./manage.sh restart
```

### Database Issues
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Restart PostgreSQL
sudo systemctl restart postgresql

# Check database connection
cd /var/www/crypto-airdrop
source .env
psql $DATABASE_URL -c "SELECT 1;"
```

### Nginx Issues
```bash
# Check Nginx status
sudo systemctl status nginx

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### General Health Check
```bash
cd /var/www/crypto-airdrop
./manage.sh health
```

## Common Issues and Solutions

**1. "Bad Gateway" Error**
- Check if application is running: `pm2 status`
- Check application logs: `pm2 logs crypto-airdrop`
- Restart application: `pm2 restart crypto-airdrop`

**2. Database Connection Error**
- Check if PostgreSQL is running: `sudo systemctl status postgresql`
- Verify database credentials in `.env` file
- Test connection: `psql $DATABASE_URL -c "SELECT 1;"`

**3. Build Failed**
- Check Node.js version: `node -v` (should be v20+)
- Check available memory: `free -h`
- Check build logs: `cat /var/www/crypto-airdrop/build.log`

**4. Port Already in Use**
- Check what's using port 5000: `sudo lsof -i :5000`
- Stop conflicting service or change port in `ecosystem.config.js`

## Security Notes

- Change default admin credentials immediately after deployment
- Consider setting up SSL/TLS with Let's Encrypt
- Regularly update system packages: `sudo apt update && sudo apt upgrade`
- Monitor application logs for suspicious activity
- Keep database backups in a secure location

## Updating Your Application

```bash
cd /var/www/crypto-airdrop
./manage.sh update
```

This will:
1. Create a backup of current version
2. Pull latest code from repository
3. Install dependencies
4. Build application
5. Restart services

## Support

If you encounter issues:
1. Run the health check: `./manage.sh health`
2. Check the logs: `./manage.sh logs`
3. Try automated fixes: `./manage.sh fix`
4. Review deployment info: `cat /var/www/crypto-airdrop/deployment-info.txt`