# Crypto Airdrop Platform - VPS Deployment

## Quick Deployment Guide

Deploy your crypto airdrop platform to any Ubuntu/Debian VPS with a single command.

### Prerequisites

- Ubuntu 20.04+ or Debian 11+ VPS
- Minimum 2GB RAM, 20GB storage
- SSH access with sudo privileges
- Ports 22, 80, 443 accessible

### Deployment Steps

1. **Connect to your VPS:**
   ```bash
   ssh user@YOUR_SERVER_IP
   ```

2. **Clone and deploy:**
   ```bash
   git clone <your-repo-url>
   cd crypto-airdrop-platform
   chmod +x deploy-vps.sh
   ./deploy-vps.sh
   ```

3. **Access your application:**
   ```
   http://YOUR_SERVER_IP
   ```

### What Gets Installed

- ✅ Node.js 20 + PM2
- ✅ PostgreSQL database
- ✅ Nginx reverse proxy  
- ✅ UFW firewall
- ✅ SSL-ready configuration
- ✅ Automated backups
- ✅ Management tools

### Post-Deployment Management

```bash
cd /var/www/crypto-airdrop

# Check status
./manage.sh status

# View logs
./manage.sh logs

# Restart application
./manage.sh restart

# Health check
./manage.sh health

# Create backup
./manage.sh backup
```

### SSL Setup (Recommended)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

### Build Process & Optimizations

The deployment script includes advanced build optimizations:

- **Extended Timeout:** 10-minute build timeout for complex applications
- **Memory Optimization:** 4GB Node.js heap size for large builds
- **Fallback Strategy:** Alternative build approach for resource-constrained VPS
- **Detailed Logging:** Comprehensive build output for troubleshooting

**Build Requirements:**
- Minimum 2GB RAM (4GB recommended)
- 20GB+ free disk space
- Stable internet connection

**If build fails:**
```bash
# Check available memory
free -h

# Monitor build process manually
NODE_OPTIONS="--max-old-space-size=4096" npm run build

# Alternative: Build locally and upload
npm run build
scp -r dist/ user@server:/var/www/crypto-airdrop/
```

### Troubleshooting

1. **Application not starting:**
   ```bash
   ./manage.sh status
   pm2 logs crypto-airdrop
   ```

2. **Database connection issues:**
   ```bash
   sudo systemctl status postgresql
   sudo -u postgres psql -l
   ```

3. **Nginx not serving:**
   ```bash
   sudo systemctl status nginx
   sudo nginx -t
   ```

4. **Firewall blocking:**
   ```bash
   sudo ufw status
   sudo ufw allow 80/tcp
   ```

### Security Notes

- Change default admin credentials after first login
- Set up SSL/TLS with Certbot for production
- Monitor logs regularly for security issues
- Keep system packages updated

### Architecture

```
Internet → Nginx (Port 80/443) → Node.js App (Port 5000) → PostgreSQL
```

The deployment creates a production-ready environment with security hardening, automated backups, and comprehensive monitoring tools.