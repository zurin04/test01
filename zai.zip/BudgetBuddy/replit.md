# HOPEMPC Cooperative Management System

## Overview

HOPEMPC is a comprehensive web-based cooperative management system designed for the HOPEMPC Cooperative. It provides powerful tools for financial tracking, loan management, member engagement, and administrative operations. The system is optimized for VPS deployment with a one-click setup script for easy installation and management.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with Vite for fast development and building
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and theming support
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Type Safety**: TypeScript throughout the application

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Storage**: PostgreSQL-backed session store using connect-pg-simple
- **Real-time Communication**: WebSocket server for officer chat functionality
- **API Design**: RESTful API with role-based access control

### Database Schema
- **Users**: Member and admin profiles with detailed personal information
- **Capital Shares**: Member equity tracking with historical updates
- **Loans**: Loan applications, approvals, and balance tracking
- **Payments**: Payment records with verification workflow
- **Funds**: Cooperative fund management (cash, capital, reserves)
- **Officers**: Officer assignments and role management
- **News Feed**: Announcements and news management
- **Financial Records**: Monthly income and expense tracking
- **Notifications**: System notifications for users
- **Member Savings**: Savings account management
- **Dividends**: Dividend distribution records

## Key Components

### Member Portal
- **Dashboard**: Financial overview with recent transactions and loan status
- **Profile Management**: Personal information updates and account settings
- **Capital Shares**: CBU tracking and loan eligibility calculation
- **Loan Management**: Application submission and status monitoring
- **Payment Interface**: Payment submission and history tracking
- **News Access**: Cooperative announcements and updates

### Admin Portal
- **Administrative Dashboard**: System metrics and overview
- **Member Management**: Registration, activation, and profile management
- **Loan Processing**: Application review, approval workflow, and monitoring
- **Payment Verification**: Payment validation and processing
- **Fund Management**: Capital, reserve, and cash flow management
- **Officer Management**: Role assignments and permissions
- **Financial Reporting**: Income, expense, and financial statement generation
- **News Management**: Content creation and publication
- **Real-time Chat**: Officer communication system

### VPS Deployment Features
- **Streamlined Setup**: Optimized one-click deployment script for Ubuntu VPS
- **Production Ready**: PM2 process management with Nginx reverse proxy
- **Database Management**: PostgreSQL setup with automatic backups
- **Management Tools**: Comprehensive management script for maintenance
- **Security Focused**: Firewall configuration and secure defaults
- **Clean Architecture**: Removed unnecessary files and consolidated documentation

## Data Flow

### Authentication Flow
1. User submits credentials via login form
2. Passport.js validates against database using scrypt password hashing
3. Session created and stored in PostgreSQL
4. Role-based routing determines user interface (member/admin)

### Loan Application Flow
1. Member submits loan application with required details
2. System validates against capital share limits and eligibility
3. Admin receives notification for review
4. Approval/rejection workflow with notes and documentation
5. Approved loans generate payment schedules and notifications

### Payment Processing Flow
1. Member submits payment through interface or counter
2. Payment record created with pending status
3. Admin verification workflow with approval controls
4. Verified payments update loan balances and generate receipts
5. Real-time balance updates across all interfaces

## External Dependencies

### Production Dependencies
- **Database**: PostgreSQL 15+ for data persistence
- **Node.js**: v20+ runtime environment
- **Authentication**: Passport.js ecosystem
- **UI Components**: Radix UI primitive components
- **Validation**: Zod schema validation
- **Date Handling**: date-fns for consistent date operations
- **Real-time**: WebSocket for live communications

### Development Dependencies
- **Build Tools**: Vite for development server and building
- **TypeScript**: Type checking and development experience
- **ESBuild**: Fast JavaScript bundling for production
- **Drizzle Kit**: Database migration and schema management

### VPS Deployment Dependencies
- **Ubuntu 20.04+**: Recommended VPS operating system
- **PM2**: Process management for production
- **Nginx**: Reverse proxy and web server
- **Let's Encrypt**: SSL certificate automation

## Deployment Strategy

### VPS Production Deployment
- **Target**: Ubuntu VPS with 2GB+ RAM
- **Build Process**: Vite builds client, ESBuild bundles server
- **Environment**: Production NODE_ENV with secure session secrets
- **Database**: Self-hosted PostgreSQL with automated backups
- **Web Server**: Nginx reverse proxy with SSL support
- **Process Management**: PM2 with automatic restart and monitoring
- **Security**: Firewall configuration and secure defaults

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Secure session encryption key
- **NODE_ENV**: Environment flag for production optimizations

## Changelog

- June 26, 2025: Initial setup and PostgreSQL database configuration
- June 26, 2025: Implemented comprehensive VPS deployment with PM2 and Nginx
- June 26, 2025: Created automated database setup and seeding system
- June 26, 2025: Fixed authentication system with proper password hashing
- June 26, 2025: Completed admin member management with CBU and savings transactions
- June 26, 2025: Added transaction history tracking for capital shares, savings, and payments
- June 26, 2025: Optimized deployment script with streamlined configuration
- June 26, 2025: Removed unnecessary files and consolidated deployment documentation
- June 26, 2025: Created management utilities for production server administration
- June 26, 2025: Enhanced CBU functionality with add/deduct/set operations and real-time WebSocket updates
- June 26, 2025: Fixed savings transaction system with proper validation and instant UI updates
- June 26, 2025: Reset admin password for sebuguerojanmark@gmail.com with proper hashing
- June 26, 2025: Fixed password authentication format mismatch between salt and hash ordering
- June 26, 2025: Implemented optimistic updates for CBU and savings with immediate UI refresh and zero stale time configuration
- June 26, 2025: Fixed CBU endpoint to fetch correct member data instead of admin data, simplified savings error handling with periodic refresh
- June 26, 2025: Resolved critical password authentication issues preventing admin password updates and member logins
- June 26, 2025: Created comprehensive password fix utility that standardized all user password formats to proper salt.hash structure
- June 26, 2025: Fixed 6 users with malformed passwords, set default password "password123" for affected accounts
- June 26, 2025: Updated VPS deployment script for current project structure with PostgreSQL setup and proper environment configuration
- June 26, 2025: Enhanced deployment script with error handling, application verification, and comprehensive database initialization
- June 27, 2025: Added SSL certificate support with Let's Encrypt integration and automatic renewal
- June 27, 2025: Enhanced backup/restore system with safe update process and automatic rollback on failures
- June 27, 2025: Improved management script with comprehensive database backup, restore, and SSL setup commands

## User Preferences

Preferred communication style: Simple, everyday language.