import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

/**
 * This script fixes users with unhashed passwords by hashing them.
 * It operates on passwords missing the '.' separator that indicates a proper hash+salt format.
 */
async function fixPasswords() {
  try {
    console.log("Checking for users with unhashed passwords...");

    // Get all users
    const users = await db.select().from(schema.users);
    
    for (const user of users) {
      // Check if password is properly hashed (should contain a '.' separator)
      if (!user.password.includes('.') || user.password.split('.').length !== 2) {
        console.log(`Fixing password for user: ${user.email}`);
        
        // Determine default password based on role
        let defaultPassword = 'admin123';
        if (user.role === 'member') {
          defaultPassword = 'member123';
        }
        
        // Hash the password properly
        const salt = randomBytes(16).toString("hex");
        const buf = (await scryptAsync(defaultPassword, salt, 64)) as Buffer;
        const hashedPassword = salt + "." + buf.toString("hex");
        
        // Update the user's password
        await db.update(schema.users)
          .set({ password: hashedPassword })
          .where(eq(schema.users.id, user.id));
          
        console.log(`✓ Fixed password for ${user.email} (role: ${user.role})`);
      } else {
        console.log(`✓ Password already properly hashed for ${user.email}`);
      }
    }
    
    console.log("Password fix completed successfully!");
  } catch (error) {
    console.error("Error fixing passwords:", error);
    process.exit(1);
  }
}

fixPasswords();