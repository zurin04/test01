import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}.${buf.toString("hex")}`;
}

async function seed() {
  try {
    console.log("Seeding database...");

    // Check if we already have a funds record
    const existingFunds = await db.select().from(schema.funds).limit(1);
    
    if (existingFunds.length === 0) {
      // Create initial funds
      await db.insert(schema.funds).values({
        onhandCash: 675000,
        capitalFund: 2450000,
        reserveFund: 500000,
        updatedAt: new Date()
      });
      console.log("Created initial funds record");
    }

    // Check if we already have the admin user
    const adminEmail = "sebuguerojanmark@gmail.com";
    const existingAdmin = await db.select().from(schema.users).where(eq(schema.users.email, adminEmail)).limit(1);
    
    if (existingAdmin.length === 0) {
      // Create admin user
      const adminUser = await db.insert(schema.users).values({
        name: "Admin User",
        email: adminEmail,
        password: await hashPassword("admin123"),
        role: "admin",
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date()
      }).returning();
      
      // Create admin's capital share
      await db.insert(schema.capitalShares).values({
        userId: adminUser[0].id,
        amount: 100000,
        updatedAt: new Date()
      });
      
      console.log("Created admin user");
    }

    // Sample data - only add if the database is empty
    const existingUsers = await db.select().from(schema.users).limit(5);
    
    if (existingUsers.length <= 1) { // Only the admin exists
      // Create sample members
      const members = [
        { name: "John Doe", email: "john@example.com", password: await hashPassword("password123"), capitalShare: 25000 },
        { name: "Maria Santos", email: "maria@example.com", password: await hashPassword("password123"), capitalShare: 35000 },
        { name: "Juan Dela Cruz", email: "juan@example.com", password: await hashPassword("password123"), capitalShare: 40000 },
        { name: "Ana Reyes", email: "ana@example.com", password: await hashPassword("password123"), capitalShare: 30000 },
        { name: "Pedro Lim", email: "pedro@example.com", password: await hashPassword("password123"), capitalShare: 20000 }
      ];
      
      for (const member of members) {
        const [user] = await db.insert(schema.users).values({
          name: member.name,
          email: member.email,
          password: member.password,
          role: "member",
          status: "active",
          createdAt: new Date(),
          updatedAt: new Date()
        }).returning();
        
        await db.insert(schema.capitalShares).values({
          userId: user.id,
          amount: member.capitalShare,
          updatedAt: new Date()
        });
        
        console.log(`Created member: ${member.name}`);
      }
      
      // Get the created users
      const createdUsers = await db.select().from(schema.users);
      
      // Create sample loans
      const loans = [
        { 
          userId: createdUsers[1].id, // Maria
          amount: 25000, 
          balance: 25000, 
          interest: 5, 
          term: 12, 
          schedule: "monthly",
          startDate: new Date(),
          status: "pending" 
        },
        { 
          userId: createdUsers[2].id, // Juan
          amount: 50000, 
          balance: 48500, 
          interest: 5, 
          term: 24, 
          schedule: "monthly",
          startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
          status: "active" 
        },
        { 
          userId: createdUsers[3].id, // Ana
          amount: 15000, 
          balance: 13800, 
          interest: 4, 
          term: 12, 
          schedule: "monthly",
          startDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 14 days ago
          status: "active" 
        },
        { 
          userId: createdUsers[4].id, // Pedro
          amount: 35000, 
          balance: 35000, 
          interest: 5, 
          term: 18, 
          schedule: "monthly",
          startDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 2 days ago
          status: "rejected" 
        }
      ];
      
      for (const loan of loans) {
        const [createdLoan] = await db.insert(schema.loans).values({
          ...loan,
          createdAt: new Date(),
          updatedAt: new Date()
        }).returning();
        
        // Add sample payments for active loans
        if (loan.status === "active") {
          // Juan's loan payments
          if (loan.userId === createdUsers[2].id) {
            await db.insert(schema.payments).values({
              loanId: createdLoan.id,
              amount: 1500,
              datePaid: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
            });
          }
          
          // Ana's loan payments
          if (loan.userId === createdUsers[3].id) {
            await db.insert(schema.payments).values({
              loanId: createdLoan.id,
              amount: 1200,
              datePaid: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
            });
          }
        }
        
        console.log(`Created loan for user ID: ${loan.userId}`);
      }
      
      // Create sample officers
      const officers = [
        { userId: createdUsers[2].id, position: "Chairperson" },
        { userId: createdUsers[1].id, position: "Treasurer" },
        { userId: createdUsers[3].id, position: "Secretary" }
      ];
      
      for (const officer of officers) {
        await db.insert(schema.officers).values({
          ...officer,
          assignedDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // 30 days ago
        });
        
        console.log(`Assigned ${officer.position} role to user ID: ${officer.userId}`);
      }
      
      // Create sample news
      const news = [
        {
          title: "New Loan Program Announcement",
          content: "We are excited to announce our new special loan program with reduced interest rates for educational purposes.",
          createdBy: 1, // Admin
          createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000) // 10 days ago
        },
        {
          title: "Annual General Meeting Schedule",
          content: "Mark your calendars! Our annual general meeting will be held on September 30, 2023 at the Community Center.",
          createdBy: 1, // Admin
          createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000) // 15 days ago
        },
        {
          title: "Office Hour Changes",
          content: "Please be informed that our office hours will change to 9:00 AM to 4:00 PM starting next month.",
          createdBy: 1, // Admin
          createdAt: new Date(Date.now() - 23 * 24 * 60 * 60 * 1000) // 23 days ago
        },
        {
          title: "Dividend Distribution Notice",
          content: "The board has approved a 5% dividend for all members. Distribution will begin on August 20, 2023.",
          createdBy: 1, // Admin
          createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000) // 45 days ago
        }
      ];
      
      for (const newsItem of news) {
        await db.insert(schema.newsFeed).values(newsItem);
        console.log(`Created news: ${newsItem.title}`);
      }
      
      // Create sample monthly income
      const incomes = [
        {
          amount: 45000,
          source: "Loan Interest",
          date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
          note: "Interest collected from active loans"
        },
        {
          amount: 35000,
          source: "Membership Fees",
          date: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000), // 18 days ago
          note: "New member registration fees"
        },
        {
          amount: 30000,
          source: "Investment Returns",
          date: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000), // 22 days ago
          note: "Returns from cooperative investments"
        },
        {
          amount: 15000,
          source: "Service Fees",
          date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000), // 25 days ago
          note: "Fees from various services"
        }
      ];
      
      for (const income of incomes) {
        await db.insert(schema.monthlyIncome).values(income);
        console.log(`Created income: ${income.source} - ₱${income.amount}`);
      }
      
      // Create sample monthly expenses
      const expenses = [
        {
          amount: 32000,
          category: "Operations",
          date: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000), // 16 days ago
          note: "General operational expenses"
        },
        {
          amount: 18000,
          category: "Utilities",
          date: new Date(Date.now() - 19 * 24 * 60 * 60 * 1000), // 19 days ago
          note: "Electricity, water, internet bills"
        },
        {
          amount: 25000,
          category: "Salaries",
          date: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000), // 21 days ago
          note: "Staff monthly salaries"
        },
        {
          amount: 10000,
          category: "Marketing",
          date: new Date(Date.now() - 26 * 24 * 60 * 60 * 1000), // 26 days ago
          note: "Promotional materials and events"
        }
      ];
      
      for (const expense of expenses) {
        await db.insert(schema.monthlyExpenses).values(expense);
        console.log(`Created expense: ${expense.category} - ₱${expense.amount}`);
      }
    }

    console.log("Database seeding completed successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
