import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { 
  BadgePlus, Search, Download, X, RefreshCw, Check, Calendar, 
  BarChart3, CreditCard, Info, Loader2, FilterIcon, ClipboardCheck 
} from "lucide-react";
import { LoanApprovalDialog } from "@/components/loan-approval-dialog";
import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { exportToExcel } from "@/lib/utils/excel";
import { Loan, User, Payment } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";

type LoanFilter = "all" | "active" | "completed" | "pending" | "rejected" | "defaulted";

// Interface for loan with detailed information
interface LoanDetails {
  loan: Loan;
  payments: Payment[];
  member: User;
}

// Form schema for creating new loan
const newLoanSchema = z.object({
  userId: z.coerce.number().positive("Please select a member"),
  amount: z.coerce.number().positive("Amount must be greater than 0"),
  interest: z.coerce.number().min(0, "Interest cannot be negative"),
  term: z.coerce.number().min(1, "Term must be at least 1 month"),
  schedule: z.string().min(1, "Please select a payment schedule"),
  startDate: z.date(),
  status: z.string().default("pending"),
});

type NewLoanFormValues = z.infer<typeof newLoanSchema>;

// Form schema for recording payment
const paymentSchema = z.object({
  amount: z.coerce.number().positive("Amount must be greater than 0"),
});

type PaymentFormValues = z.infer<typeof paymentSchema>;

export default function AdminLoans() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState<LoanFilter>("all");
  const [showNewLoanDialog, setShowNewLoanDialog] = useState(false);
  const [showLoanDetailsDialog, setShowLoanDetailsDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showApprovalDialog, setShowApprovalDialog] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState<LoanDetails | null>(null);
  const [loanForApproval, setLoanForApproval] = useState<Loan | null>(null);
  
  // Fetch loans
  const { data: loans, isLoading: isLoadingLoans } = useQuery<Loan[]>({
    queryKey: ["/api/admin/loans"],
  });
  
  // Listen for loan approval events from notifications
  useEffect(() => {
    // Skip until loans are loaded
    if (!loans) return;
    
    const handleOpenLoanApproval = (event: CustomEvent<{loanId: number}>) => {
      const loanId = event.detail.loanId;
      const loan = loans.find(l => l.id === loanId);
      
      if (loan) {
        setLoanForApproval(loan);
        setShowApprovalDialog(true);
        
        // Set filter to pending to make it easier to see similar loans
        setFilter("pending");
        
        toast({
          title: "Loan Application Ready for Review",
          description: `Reviewing loan #${loanId} from member #${loan.userId}`,
        });
      } else {
        toast({
          title: "Error",
          description: `Loan #${loanId} not found or may have been processed already.`,
          variant: "destructive",
        });
        
        // Refresh loans data
        queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      }
    };
    
    // Add event listener for custom loan approval events
    window.addEventListener('openLoanApproval', handleOpenLoanApproval as EventListener);
    
    return () => {
      window.removeEventListener('openLoanApproval', handleOpenLoanApproval as EventListener);
    };
  }, [loans, queryClient, toast]);

  // Fetch active members for loan creation
  const { data: members, isLoading: isLoadingMembers } = useQuery<User[]>({
    queryKey: ["/api/admin/members/active"],
  });

  // Forms
  const newLoanForm = useForm<NewLoanFormValues>({
    resolver: zodResolver(newLoanSchema),
    defaultValues: {
      userId: undefined,
      amount: undefined,
      interest: 5, // Default interest rate
      term: 12, // Default term in months
      schedule: "monthly",
      startDate: new Date(),
      status: "pending",
    },
  });

  const paymentForm = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      amount: undefined,
    },
  });

  // Create loan mutation
  const createLoanMutation = useMutation({
    mutationFn: async (values: NewLoanFormValues) => {
      const res = await apiRequest("POST", "/api/admin/loans", {
        ...values,
        balance: values.amount, // Initial balance is the full amount
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      
      toast({
        title: "Success",
        description: "Loan has been created successfully.",
      });
      
      setShowNewLoanDialog(false);
      newLoanForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create loan.",
        variant: "destructive",
      });
    },
  });

  // Record payment mutation
  const recordPaymentMutation = useMutation({
    mutationFn: async ({ loanId, amount }: { loanId: number, amount: number }) => {
      const res = await apiRequest("POST", `/api/admin/loans/${loanId}/payments`, { amount });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      if (selectedLoan) {
        queryClient.invalidateQueries({ queryKey: [`/api/admin/loans/${selectedLoan.loan.id}`] });
      }
      
      toast({
        title: "Success",
        description: "Payment has been recorded successfully.",
      });
      
      setShowPaymentDialog(false);
      paymentForm.reset();
      
      // Refresh loan details if they're being viewed
      if (selectedLoan && showLoanDetailsDialog) {
        fetchLoanDetails(selectedLoan.loan.id);
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to record payment.",
        variant: "destructive",
      });
    },
  });

  // Update loan status mutation
  const updateLoanStatusMutation = useMutation({
    mutationFn: async ({ loanId, status }: { loanId: number, status: string }) => {
      const res = await apiRequest("PUT", `/api/admin/loans/${loanId}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      if (selectedLoan) {
        queryClient.invalidateQueries({ queryKey: [`/api/admin/loans/${selectedLoan.loan.id}`] });
      }
      
      toast({
        title: "Success",
        description: "Loan status has been updated.",
      });
      
      // Refresh loan details if they're being viewed
      if (selectedLoan && showLoanDetailsDialog) {
        fetchLoanDetails(selectedLoan.loan.id);
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update loan status.",
        variant: "destructive",
      });
    },
  });

  // Handle new loan form submission
  const onSubmitNewLoan = (values: NewLoanFormValues) => {
    createLoanMutation.mutate(values);
  };

  // Handle payment form submission
  const onSubmitPayment = (values: PaymentFormValues) => {
    if (!selectedLoan) return;
    
    recordPaymentMutation.mutate({
      loanId: selectedLoan.loan.id,
      amount: values.amount,
    });
  };

  // Fetch loan details
  const fetchLoanDetails = async (loanId: number) => {
    try {
      const res = await fetch(`/api/admin/loans/${loanId}`);
      if (!res.ok) throw new Error("Failed to fetch loan details");
      
      const data = await res.json();
      setSelectedLoan(data);
      setShowLoanDetailsDialog(true);
    } catch (error) {
      console.error("Error fetching loan details:", error);
      toast({
        title: "Error",
        description: "Failed to fetch loan details.",
        variant: "destructive",
      });
    }
  };

  // Filter loans based on search term and status filter
  const filteredLoans = loans?.filter(loan => {
    const matchesSearch = 
      searchTerm === "" || 
      loan.id.toString().includes(searchTerm) || 
      loan.userId.toString().includes(searchTerm) || 
      loan.amount.toString().includes(searchTerm);
    
    const matchesStatus = filter === "all" || loan.status === filter;
    
    return matchesSearch && matchesStatus;
  });

  // Calculate loan metrics
  const totalLoans = loans?.length || 0;
  const activeLoans = loans?.filter(loan => loan.status === "active").length || 0;
  const completedLoans = loans?.filter(loan => loan.status === "completed").length || 0;
  const pendingLoans = loans?.filter(loan => loan.status === "pending").length || 0;
  
  const totalActiveLoanAmount = loans
    ?.filter(loan => loan.status === "active")
    .reduce((sum, loan) => sum + loan.balance, 0) || 0;

  const getLoanStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>;
      case "completed":
        return <Badge className="bg-blue-500">Completed</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case "defaulted":
        return <Badge variant="destructive">Defaulted</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Export loans to Excel
  const handleExport = () => {
    if (!loans || loans.length === 0) {
      toast({
        title: "Export Failed",
        description: "No loans data available to export.",
        variant: "destructive",
      });
      return;
    }
    
    const columns = [
      { key: "id", header: "ID" },
      { key: "userId", header: "Member ID" },
      { key: "amount", header: "Amount" },
      { key: "balance", header: "Balance" },
      { key: "interest", header: "Interest Rate" },
      { key: "term", header: "Term (Months)" },
      { key: "schedule", header: "Payment Schedule" },
      { key: "startDate", header: "Start Date" },
      { key: "status", header: "Status" },
      { key: "createdAt", header: "Created Date" },
    ];
    
    // Format dates before export
    const formattedLoans = loans.map(loan => ({
      ...loan,
      startDate: format(new Date(loan.startDate), "yyyy-MM-dd"),
      createdAt: format(new Date(loan.createdAt), "yyyy-MM-dd"),
    }));
    
    exportToExcel(formattedLoans, {
      filename: `hopempc-loans-${filter}`,
      sheetName: "Loans",
      columns,
    });
    
    toast({
      title: "Export Successful",
      description: `${formattedLoans.length} loans exported to Excel.`,
    });
  };

  return (
    <AdminLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold">Loans Management</h1>
        
        <div className="flex mt-4 sm:mt-0 gap-2">
          <Dialog open={showNewLoanDialog} onOpenChange={setShowNewLoanDialog}>
            <DialogTrigger asChild>
              <Button>
                <BadgePlus className="mr-2 h-4 w-4" />
                New Loan
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Create New Loan</DialogTitle>
                <DialogDescription>
                  Set up a new loan for a cooperative member.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...newLoanForm}>
                <form onSubmit={newLoanForm.handleSubmit(onSubmitNewLoan)} className="space-y-4">
                  <FormField
                    control={newLoanForm.control}
                    name="userId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Member</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          value={field.value?.toString() || ""}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a member" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {isLoadingMembers ? (
                              <SelectItem value="loading" disabled>
                                Loading members...
                              </SelectItem>
                            ) : members && members.length > 0 ? (
                              members.map((member) => (
                                <SelectItem key={member.id} value={member.id.toString()}>
                                  {member.name} (#{member.id})
                                </SelectItem>
                              ))
                            ) : (
                              <SelectItem value="none" disabled>
                                No active members available
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={newLoanForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Loan Amount (₱)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={newLoanForm.control}
                      name="interest"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Interest Rate (%)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={newLoanForm.control}
                      name="term"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Term (Months)</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={newLoanForm.control}
                      name="schedule"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Schedule</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select schedule" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={newLoanForm.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Start Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground"
                                  )}
                                >
                                  {field.value ? (
                                    format(field.value, "PPP")
                                  ) : (
                                    <span>Pick a date</span>
                                  )}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <CalendarComponent
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={newLoanForm.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Initial Status</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="rejected">Rejected</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowNewLoanDialog(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createLoanMutation.isPending || isLoadingMembers}
                    >
                      {createLoanMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="mr-2 h-4 w-4" />
                      )}
                      Create Loan
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </Button>
        </div>
      </div>
      
      {/* Loan Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Total Loans</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{totalLoans}</p>
                )}
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                <BarChart3 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Active Loans</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{activeLoans}</p>
                )}
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                <Check className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Pending Approval</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{pendingLoans}</p>
                )}
              </div>
              <div className="p-2 bg-yellow-100 dark:bg-yellow-900/30 rounded-md">
                <Calendar className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Outstanding Balance</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-24 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">
                    ₱{totalActiveLoanAmount.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </p>
                )}
              </div>
              <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-md">
                <CreditCard className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Pending Loan Applications */}
      {pendingLoans > 0 && (
        <Card className="mb-6 border-2 border-yellow-300 dark:border-yellow-700 bg-yellow-50 dark:bg-yellow-900/20">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="flex items-center text-yellow-700 dark:text-yellow-500">
                  <ClipboardCheck className="mr-2 h-5 w-5" />
                  Pending Loan Applications
                </CardTitle>
                <CardDescription>These loans require your review and approval</CardDescription>
              </div>
              <Badge className="bg-yellow-500 dark:bg-yellow-600">{pendingLoans} pending</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {loans?.filter(loan => loan.status === "pending").map((loan) => (
              <div key={loan.id} className="mb-4 last:mb-0 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-medium">Loan #{loan.id} from Member #{loan.userId}</h4>
                    <p className="text-sm text-muted-foreground">
                      Applied on {format(new Date(loan.createdAt), "MMM d, yyyy")}
                    </p>
                  </div>
                  <Badge className="bg-yellow-500">Pending</Badge>
                </div>
                
                <div className="grid grid-cols-3 gap-4 mb-3">
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="font-medium">₱{loan.amount.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Term</p>
                    <p className="font-medium">{loan.term} months</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Interest</p>
                    <p className="font-medium">{loan.interest}%</p>
                  </div>
                </div>
                
                <Button 
                  className="bg-green-500 hover:bg-green-600 text-white w-full sm:w-auto"
                  size="sm"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log("Review button clicked for loan:", loan.id);
                    setLoanForApproval(loan);
                    setShowApprovalDialog(true);
                  }}
                >
                  <ClipboardCheck className="mr-2 h-4 w-4" />
                  Review Application
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* All Loans List */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>All Loan Applications</CardTitle>
              <CardDescription>Complete history of loan applications and their current status</CardDescription>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-8 w-full sm:w-[200px]"
                  placeholder="Search loans..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              <Select 
                value={filter} 
                onValueChange={(value) => setFilter(value as LoanFilter)}
              >
                <SelectTrigger className="w-full sm:w-[140px]">
                  <FilterIcon className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Loans</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="defaulted">Defaulted</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
                }}
                disabled={isLoadingLoans}
              >
                <RefreshCw className={`h-4 w-4 ${isLoadingLoans ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingLoans ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : filteredLoans && filteredLoans.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Member ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead>Interest</TableHead>
                    <TableHead>Term</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLoans.map((loan) => (
                    <TableRow key={loan.id}>
                      <TableCell className="font-medium">#{loan.id}</TableCell>
                      <TableCell>#{loan.userId}</TableCell>
                      <TableCell>₱{loan.amount.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}</TableCell>
                      <TableCell>₱{loan.balance.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}</TableCell>
                      <TableCell>{loan.interest}%</TableCell>
                      <TableCell>{loan.term} months</TableCell>
                      <TableCell>{format(new Date(loan.startDate), "MMM d, yyyy")}</TableCell>
                      <TableCell>{getLoanStatusBadge(loan.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => fetchLoanDetails(loan.id)}
                          >
                            <Info className="h-4 w-4" />
                          </Button>
                          
                          {loan.status === "pending" && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="bg-green-50 hover:bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400 hover:text-green-700"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                console.log("Table Review button clicked for loan:", loan.id);
                                setLoanForApproval(loan);
                                setShowApprovalDialog(true);
                              }}
                            >
                              <ClipboardCheck className="mr-1 h-4 w-4" />
                              Review
                            </Button>
                          )}
                          
                          {loan.status === "active" && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 hover:text-blue-700"
                              onClick={() => {
                                setSelectedLoan({
                                  loan, 
                                  payments: [],
                                  member: { id: loan.userId } as User // Placeholder, will be filled when details are fetched
                                });
                                setShowPaymentDialog(true);
                              }}
                            >
                              Pay
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10">
              <CreditCard className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <h3 className="text-lg font-medium mb-1">No Loans Found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm 
                  ? "No loans match your search criteria." 
                  : `No ${filter !== "all" ? filter : ""} loans found.`}
              </p>
              {searchTerm && (
                <Button 
                  variant="outline" 
                  onClick={() => setSearchTerm("")}
                >
                  Clear Search
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Loan Details Dialog */}
      <Dialog open={showLoanDetailsDialog} onOpenChange={setShowLoanDetailsDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Loan Details</DialogTitle>
            <DialogDescription>
              Detailed information about loan #{selectedLoan?.loan.id}
            </DialogDescription>
          </DialogHeader>
          
          {selectedLoan ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Member</h4>
                  <p className="text-lg font-semibold">{selectedLoan.member?.name || `ID: ${selectedLoan.loan.userId}`}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Status</h4>
                  <div className="mt-1">{getLoanStatusBadge(selectedLoan.loan.status)}</div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Amount</h4>
                  <p className="text-lg font-semibold">₱{selectedLoan.loan.amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Current Balance</h4>
                  <p className="text-lg font-semibold">₱{selectedLoan.loan.balance.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Interest Rate</h4>
                  <p>{selectedLoan.loan.interest}% per annum</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Term</h4>
                  <p>{selectedLoan.loan.term} months</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Payment Schedule</h4>
                  <p className="capitalize">{selectedLoan.loan.schedule}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Start Date</h4>
                  <p>{format(new Date(selectedLoan.loan.startDate), "MMMM d, yyyy")}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Created On</h4>
                  <p>{format(new Date(selectedLoan.loan.createdAt), "MMMM d, yyyy")}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Last Updated</h4>
                  <p>{format(new Date(selectedLoan.loan.updatedAt), "MMMM d, yyyy")}</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Payment History</h4>
                {selectedLoan.payments && selectedLoan.payments.length > 0 ? (
                  <div className="border rounded-md">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedLoan.payments.map(payment => (
                          <TableRow key={payment.id}>
                            <TableCell>{format(new Date(payment.datePaid), "MMM d, yyyy")}</TableCell>
                            <TableCell>₱{payment.amount.toLocaleString('en-PH', {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2
                            })}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-center py-4 text-muted-foreground text-sm">
                    No payment records found for this loan.
                  </p>
                )}
              </div>
              
              <div className="flex justify-between">
                {selectedLoan.loan.status === "active" && (
                  <Button
                    onClick={() => {
                      setShowLoanDetailsDialog(false);
                      setShowPaymentDialog(true);
                    }}
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    Record Payment
                  </Button>
                )}
                
                {selectedLoan.loan.status === "pending" && (
                  <div className="space-x-2">
                    <Button
                      variant="outline"
                      className="bg-red-50 hover:bg-red-100 text-red-600 hover:text-red-700"
                      onClick={() => updateLoanStatusMutation.mutate({
                        loanId: selectedLoan.loan.id,
                        status: "rejected"
                      })}
                    >
                      Reject Loan
                    </Button>
                    <Button
                      className="bg-green-600 hover:bg-green-700"
                      onClick={() => updateLoanStatusMutation.mutate({
                        loanId: selectedLoan.loan.id,
                        status: "active"
                      })}
                    >
                      Approve Loan
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="py-8 text-center">
              <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
              <p className="mt-2 text-muted-foreground">Loading loan details...</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Loan Payment</DialogTitle>
            <DialogDescription>
              Enter payment details for loan #{selectedLoan?.loan.id}
            </DialogDescription>
          </DialogHeader>
          
          {selectedLoan && (
            <Form {...paymentForm}>
              <form onSubmit={paymentForm.handleSubmit(onSubmitPayment)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Loan Amount</Label>
                    <Input 
                      value={`₱${selectedLoan.loan.amount.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}`} 
                      disabled 
                    />
                  </div>
                  <div>
                    <Label>Current Balance</Label>
                    <Input 
                      value={`₱${selectedLoan.loan.balance.toLocaleString('en-PH', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}`} 
                      disabled 
                    />
                  </div>
                </div>
                
                <FormField
                  control={paymentForm.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payment Amount (₱)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowPaymentDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={recordPaymentMutation.isPending}
                  >
                    {recordPaymentMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Check className="mr-2 h-4 w-4" />
                    )}
                    Record Payment
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>

      {/* Loan Approval Dialog */}
      {loanForApproval && (
        <LoanApprovalDialog
          loan={loanForApproval}
          isOpen={showApprovalDialog}
          onClose={() => {
            setShowApprovalDialog(false);
            setLoanForApproval(null);
          }}
        />
      )}
    </AdminLayout>
  );
}
