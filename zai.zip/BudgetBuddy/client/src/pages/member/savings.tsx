import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { PiggyBank, TrendingUp, Calendar, ArrowUp, ArrowDown } from "lucide-react";
import MemberLayout from "@/layouts/member-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { CapitalShare, MemberSavings } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function MemberSavingsPage() {
  const { user } = useAuth();

  // Fetch capital share for CBU interest calculation
  const { data: capitalShare, isLoading: isLoadingCapitalShare } = useQuery<CapitalShare>({
    queryKey: ["/api/members/capital-shares"],
  });

  // Fetch savings data
  const { data: savingsData, isLoading: isLoadingSavings } = useQuery<{transactions: MemberSavings[], balance: number}>({
    queryKey: ["/api/members/savings"],
  });

  // Calculate CBU annual interest at 10% APY
  const calculateCBUInterest = () => {
    if (!capitalShare?.amount) return 0;
    const annualInterestRate = 0.10; // 10% APY
    return capitalShare.amount * annualInterestRate;
  };

  const cbuAnnualInterest = calculateCBUInterest();
  const cbuMonthlyInterest = cbuAnnualInterest / 12;

  return (
    <MemberLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Savings & CBU Overview</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Manage your savings account and track your Capital Build-Up (CBU) interest earnings
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Savings Balance Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Savings Balance</CardTitle>
              <PiggyBank className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoadingSavings ? (
                  <Skeleton className="h-8 w-32" />
                ) : (
                  `₱${savingsData?.balance?.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || "0.00"}`
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Available for withdrawal
              </p>
            </CardContent>
          </Card>

          {/* CBU Balance Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">CBU Balance</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoadingCapitalShare ? (
                  <Skeleton className="h-8 w-32" />
                ) : (
                  `₱${capitalShare?.amount?.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || "0.00"}`
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Capital Build-Up shares
              </p>
            </CardContent>
          </Card>

          {/* Annual Interest Card */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Annual CBU Interest (10% APY)</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {isLoadingCapitalShare ? (
                  <Skeleton className="h-8 w-32" />
                ) : (
                  `₱${cbuAnnualInterest.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Monthly: ₱{cbuMonthlyInterest.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* CBU Interest Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>CBU Interest Calculation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Interest Breakdown</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <span className="text-sm">Current CBU Balance:</span>
                    <span className="font-medium">₱{capitalShare?.amount?.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || "0.00"}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <span className="text-sm">Interest Rate (APY):</span>
                    <span className="font-medium text-green-600">10.00%</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                    <span className="text-sm font-medium">Annual Interest:</span>
                    <span className="font-bold text-green-600">₱{cbuAnnualInterest.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Projected Monthly Interest</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <span className="text-sm">Monthly Interest:</span>
                    <span className="font-medium">₱{cbuMonthlyInterest.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <span className="text-sm">Quarterly Interest:</span>
                    <span className="font-medium">₱{(cbuAnnualInterest / 4).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-2">
                    * Interest calculations are based on current CBU balance and 10% Annual Percentage Yield (APY)
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Savings Transactions */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Savings Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingSavings ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : savingsData?.transactions && savingsData.transactions.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Balance After</TableHead>
                      <TableHead>Note</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {savingsData.transactions.slice(0, 10).map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="text-sm">
                          {format(new Date(transaction.date), "MMM d, yyyy h:mm a")}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {transaction.transactionType === 'deposit' ? (
                              <ArrowUp className="h-4 w-4 text-green-500" />
                            ) : (
                              <ArrowDown className="h-4 w-4 text-red-500" />
                            )}
                            <span className={`capitalize font-medium ${
                              transaction.transactionType === 'deposit' 
                                ? 'text-green-600 dark:text-green-400' 
                                : 'text-red-600 dark:text-red-400'
                            }`}>
                              {transaction.transactionType}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">
                          <span className={transaction.transactionType === 'deposit' ? 'text-green-600' : 'text-red-600'}>
                            {transaction.transactionType === 'deposit' ? '+' : '-'}₱{transaction.amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </TableCell>
                        <TableCell className="font-medium">
                          ₱{transaction.balance.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {transaction.note || 'No note'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <PiggyBank className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No savings transactions yet.</p>
                <p className="text-sm">Contact an administrator to make your first deposit.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MemberLayout>
  );
}