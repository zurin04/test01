import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { User, Edit, Loader2 } from "lucide-react";
import MemberLayout from "@/layouts/member-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface ProfileData {
  user: {
    id: number;
    name: string;
    email: string;
    role: string;
    status: string;
    createdAt: string;
  };
  capitalShare: {
    id: number;
    userId: number;
    amount: number;
    updatedAt: string;
  } | null;
}

export default function MemberProfile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [name, setName] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);

  const { data: profileData, isLoading, refetch } = useQuery<ProfileData>({
    queryKey: ["/api/members/profile"],
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const handleEditProfile = async () => {
    if (!name.trim()) {
      toast({
        title: "Error",
        description: "Name cannot be empty",
        variant: "destructive",
      });
      return;
    }

    setIsUpdating(true);
    try {
      await apiRequest("PUT", `/api/members/${user?.id}`, { name });
      
      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      
      refetch();
      setIsEditDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <MemberLayout>
      <h1 className="text-2xl font-bold mb-6">My Profile</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>
              Your personal and account details
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            {isLoading ? (
              <>
                <Skeleton className="h-24 w-24 rounded-full" />
                <Skeleton className="h-6 w-48" />
                <Skeleton className="h-5 w-36" />
                <Skeleton className="h-5 w-56" />
              </>
            ) : (
              <>
                <Avatar className="h-24 w-24">
                  <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                    {getInitials(profileData?.user.name || "User")}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-semibold text-center">
                  {profileData?.user.name}
                </h2>
                <p className="text-gray-500 dark:text-gray-400">
                  Member ID: #{profileData?.user.id}
                </p>
                <p className="text-gray-500 dark:text-gray-400">
                  Email: {profileData?.user.email}
                </p>
                <p className="text-gray-500 dark:text-gray-400">
                  Status:{" "}
                  <span
                    className={`font-medium ${
                      profileData?.user.status === "active"
                        ? "text-green-500"
                        : "text-red-500"
                    }`}
                  >
                    {profileData?.user.status === "active" ? "Active" : "Inactive"}
                  </span>
                </p>
                <p className="text-gray-500 dark:text-gray-400">
                  Member since:{" "}
                  {profileData?.user.createdAt
                    ? format(new Date(profileData.user.createdAt), "MMMM d, yyyy")
                    : "N/A"}
                </p>

                <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() => setName(profileData?.user.name || "")}
                    >
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Profile
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                      <DialogDescription>
                        Update your profile information
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          value={profileData?.user.email}
                          disabled
                        />
                        <p className="text-sm text-gray-500">
                          Email cannot be changed
                        </p>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => setIsEditDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button onClick={handleEditProfile} disabled={isUpdating}>
                        {isUpdating ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : null}
                        Save Changes
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </>
            )}
          </CardContent>
        </Card>

        {/* Capital Share Card */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle>Capital Share Details</CardTitle>
            <CardDescription>
              Your capital share information and transactions
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-64 w-full" />
              </div>
            ) : (
              <>
                <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 mb-6">
                  <div className="flex items-center space-x-4">
                    <div className="rounded-full bg-primary/20 p-3">
                      <User className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Current Capital Share
                      </p>
                      <p className="text-2xl font-bold">
                        ₱
                        {profileData?.capitalShare?.amount.toLocaleString(
                          "en-PH",
                          {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          }
                        ) || "0.00"}
                      </p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Last updated:{" "}
                        {profileData?.capitalShare?.updatedAt
                          ? format(
                              new Date(profileData.capitalShare.updatedAt),
                              "MMMM d, yyyy"
                            )
                          : "N/A"}
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">
                    Capital Share Transaction History
                  </h3>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Balance</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {/* This would typically show transaction history */}
                        {/* For now we'll just display an empty state */}
                        <TableRow>
                          <TableCell
                            colSpan={4}
                            className="text-center py-6 text-gray-500 dark:text-gray-400"
                          >
                            No capital share transactions available.
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </MemberLayout>
  );
}
