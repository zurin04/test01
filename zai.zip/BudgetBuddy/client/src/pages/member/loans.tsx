import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { CalendarIcon, Download, Search, X, AlertTriangle, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import MemberLayout from "@/layouts/member-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loan, Payment } from "@shared/schema";
import { Link } from "wouter";

type LoanStatus = "active" | "completed" | "rejected" | "pending" | "defaulted" | "all";

interface LoanWithPayments {
  loan: Loan;
  payments: Payment[];
}

export default function MemberLoans() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<LoanStatus>("all");
  const [selectedLoan, setSelectedLoan] = useState<LoanWithPayments | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  // Fetch loans
  const { data: loans, isLoading: isLoadingLoans } = useQuery<Loan[]>({
    queryKey: ["/api/members/loans"],
  });

  // Filter loans based on search term and status
  const filteredLoans = loans?.filter((loan) => {
    const matchesSearch = 
      searchTerm === "" || 
      loan.id.toString().includes(searchTerm) || 
      loan.amount.toString().includes(searchTerm);
    
    const matchesStatus = statusFilter === "all" || loan.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Calculate loan metrics
  const totalLoans = loans?.length || 0;
  const activeLoans = loans?.filter(loan => loan.status === "active").length || 0;
  const completedLoans = loans?.filter(loan => loan.status === "completed").length || 0;
  const totalBalance = loans?.reduce((sum, loan) => 
    loan.status === "active" ? sum + loan.balance : sum, 0
  ) || 0;

  // Handle loan details view
  const viewLoanDetails = async (loanId: number) => {
    try {
      const response = await fetch(`/api/members/loans/${loanId}`);
      if (!response.ok) throw new Error("Failed to fetch loan details");
      
      const data: LoanWithPayments = await response.json();
      setSelectedLoan(data);
      setDetailsOpen(true);
    } catch (error) {
      console.error("Error fetching loan details:", error);
    }
  };

  const getLoanStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Active</Badge>;
      case "completed":
        return <Badge className="bg-blue-500">Completed</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case "defaulted":
        return <Badge variant="destructive">Defaulted</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <MemberLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold">My Loans</h1>
      </div>
      
      {/* Loan Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Loans</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{totalLoans}</p>
                )}
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                <CalendarIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Loans</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{activeLoans}</p>
                )}
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                <CalendarIcon className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Completed Loans</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{completedLoans}</p>
                )}
              </div>
              <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-md">
                <CalendarIcon className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Balance</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-24 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">₱{totalBalance.toLocaleString('en-PH', {
                    minimumFractionDigits: 2, 
                    maximumFractionDigits: 2
                  })}</p>
                )}
              </div>
              <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-md">
                <CalendarIcon className="h-5 w-5 text-orange-600 dark:text-orange-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Loan List */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Loan History</CardTitle>
              <CardDescription>View and manage your loans</CardDescription>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-8 w-full sm:w-[200px]"
                  placeholder="Search loans..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              <Select 
                value={statusFilter} 
                onValueChange={(value) => setStatusFilter(value as LoanStatus)}
              >
                <SelectTrigger className="w-full sm:w-[160px]">
                  <SelectValue placeholder="Filter status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="defaulted">Defaulted</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" className="hidden sm:flex items-center">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingLoans ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : loans && loans.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead>Interest</TableHead>
                    <TableHead>Term</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLoans && filteredLoans.length > 0 ? (
                    filteredLoans.map((loan) => (
                      <TableRow key={loan.id}>
                        <TableCell>#{loan.id}</TableCell>
                        <TableCell>₱{loan.amount.toLocaleString('en-PH', {
                          minimumFractionDigits: 2, 
                          maximumFractionDigits: 2
                        })}</TableCell>
                        <TableCell>₱{loan.balance.toLocaleString('en-PH', {
                          minimumFractionDigits: 2, 
                          maximumFractionDigits: 2
                        })}</TableCell>
                        <TableCell>{loan.interest}%</TableCell>
                        <TableCell>{loan.term} months</TableCell>
                        <TableCell>{format(new Date(loan.startDate), "MMM d, yyyy")}</TableCell>
                        <TableCell>{getLoanStatusBadge(loan.status)}</TableCell>
                        <TableCell>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => viewLoanDetails(loan.id)}
                          >
                            Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        No matching loans found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12 px-4">
              <AlertTriangle className="mx-auto h-10 w-10 text-yellow-500 mb-3" />
              <h3 className="text-lg font-medium">No Loans Found</h3>
              <p className="text-muted-foreground mt-2 mb-6">
                You don't have any loans in the system yet.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Loan Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Loan Details</DialogTitle>
            <DialogDescription>
              Detailed information about loan #{selectedLoan?.loan.id}
            </DialogDescription>
          </DialogHeader>
          
          {selectedLoan && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Amount</h4>
                  <p className="text-lg font-semibold">₱{selectedLoan.loan.amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Current Balance</h4>
                  <p className="text-lg font-semibold">₱{selectedLoan.loan.balance.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Interest Rate</h4>
                  <p>{selectedLoan.loan.interest}% per annum</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Term Length</h4>
                  <p>{selectedLoan.loan.term} months</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Payment Schedule</h4>
                  <p className="capitalize">{selectedLoan.loan.schedule}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Status</h4>
                  <div className="mt-1">{getLoanStatusBadge(selectedLoan.loan.status)}</div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Start Date</h4>
                  <p>{format(new Date(selectedLoan.loan.startDate), "MMMM d, yyyy")}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground">Last Updated</h4>
                  <p>{format(new Date(selectedLoan.loan.updatedAt), "MMMM d, yyyy")}</p>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-3">Payment History</h4>
                {selectedLoan.payments && selectedLoan.payments.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedLoan.payments.map(payment => (
                          <TableRow key={payment.id}>
                            <TableCell>{format(new Date(payment.datePaid), "MMM d, yyyy")}</TableCell>
                            <TableCell>₱{payment.amount.toLocaleString('en-PH', {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2
                            })}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-center py-4 text-muted-foreground text-sm">
                    No payment records found for this loan.
                  </p>
                )}
              </div>
              
              {selectedLoan.loan.status === "active" && (
                <div className="flex justify-end">
                  <Link href={`/payments?loanId=${selectedLoan.loan.id}`}>
                    <Button className="flex items-center">
                      Make a Payment
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </MemberLayout>
  );
}
