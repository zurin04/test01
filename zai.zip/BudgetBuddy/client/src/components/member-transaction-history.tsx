import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { TrendingUp, TrendingDown, CreditCard, Wallet, ArrowUpRight, ArrowDownRight } from "lucide-react";

type MemberTransactionHistoryProps = {
  memberId: number | null;
  memberName: string;
  isOpen: boolean;
  onClose: () => void;
};

type Transaction = {
  id: number;
  amount: number;
  description?: string;
  createdAt: string;
  processorName?: string;
  transactionType: string;
  previousAmount?: number;
  newAmount?: number;
  previousBalance?: number;
  newBalance?: number;
};

export function MemberTransactionHistory({ 
  memberId, 
  memberName, 
  isOpen, 
  onClose 
}: MemberTransactionHistoryProps) {
  const { data: transactionHistory, isLoading } = useQuery({
    queryKey: ['/api/admin/members', memberId, 'transactions'],
    enabled: isOpen && !!memberId
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP'
    }).format(amount);
  };

  const getTransactionIcon = (type: string, amount: number) => {
    if (type === 'add' || type === 'deposit') {
      return <ArrowUpRight className="h-4 w-4 text-green-600" />;
    }
    if (type === 'deduct' || type === 'withdrawal') {
      return <ArrowDownRight className="h-4 w-4 text-red-600" />;
    }
    return <CreditCard className="h-4 w-4 text-blue-600" />;
  };

  const getTransactionColor = (type: string) => {
    if (type === 'add' || type === 'deposit') return 'text-green-600';
    if (type === 'deduct' || type === 'withdrawal') return 'text-red-600';
    return 'text-blue-600';
  };

  const capitalShareTransactions = transactionHistory?.capitalShareTransactions || [];
  const savingsTransactions = transactionHistory?.savingsTransactions || [];
  const paymentHistory = transactionHistory?.paymentHistory || [];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            Transaction History - {memberName}
          </DialogTitle>
          <DialogDescription>
            Complete financial transaction history for this member
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="capital-shares">CBU Transactions</TabsTrigger>
              <TabsTrigger value="savings">Savings Transactions</TabsTrigger>
              <TabsTrigger value="payments">Payment History</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">CBU Transactions</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{capitalShareTransactions.length}</div>
                    <p className="text-xs text-muted-foreground">
                      Total CBU adjustments
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Savings Transactions</CardTitle>
                    <Wallet className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{savingsTransactions.length}</div>
                    <p className="text-xs text-muted-foreground">
                      Total savings activities
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Loan Payments</CardTitle>
                    <CreditCard className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{paymentHistory.length}</div>
                    <p className="text-xs text-muted-foreground">
                      Total loan payments
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Transactions Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest transactions across all categories</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Combine and sort all transactions by date */}
                    {[
                      ...capitalShareTransactions.map(t => ({ ...t, category: 'CBU' })),
                      ...savingsTransactions.map(t => ({ ...t, category: 'Savings' })),
                      ...paymentHistory.map(t => ({ ...t, category: 'Payment', createdAt: t.datePaid }))
                    ]
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .slice(0, 10)
                      .map((transaction, index) => (
                        <div key={`${transaction.category}-${transaction.id}-${index}`} 
                             className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            {getTransactionIcon(transaction.transactionType || 'payment', transaction.amount)}
                            <div>
                              <p className="font-medium">
                                {transaction.category} - {transaction.transactionType || 'Payment'}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {transaction.description || 'No description'}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`font-medium ${getTransactionColor(transaction.transactionType || 'payment')}`}>
                              {formatCurrency(transaction.amount)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(transaction.createdAt), 'MMM dd, yyyy')}
                            </p>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="capital-shares">
              <Card>
                <CardHeader>
                  <CardTitle>CBU Transaction History</CardTitle>
                  <CardDescription>
                    All capital share additions and deductions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Previous</TableHead>
                        <TableHead>New Balance</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Processed By</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {capitalShareTransactions.map((transaction) => (
                        <TableRow key={transaction.id}>
                          <TableCell>
                            {format(new Date(transaction.createdAt), 'MMM dd, yyyy HH:mm')}
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={transaction.transactionType === 'add' ? 'default' : 'destructive'}
                              className="flex items-center gap-1 w-fit"
                            >
                              {getTransactionIcon(transaction.transactionType, transaction.amount)}
                              {transaction.transactionType === 'add' ? 'Addition' : 'Deduction'}
                            </Badge>
                          </TableCell>
                          <TableCell className={getTransactionColor(transaction.transactionType)}>
                            {formatCurrency(transaction.amount)}
                          </TableCell>
                          <TableCell>
                            {formatCurrency(transaction.previousAmount || 0)}
                          </TableCell>
                          <TableCell className="font-medium">
                            {formatCurrency(transaction.newAmount || 0)}
                          </TableCell>
                          <TableCell>
                            {transaction.description || 'No description'}
                          </TableCell>
                          <TableCell>
                            {transaction.processorName || 'System'}
                          </TableCell>
                        </TableRow>
                      ))}
                      {capitalShareTransactions.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            No CBU transactions found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="savings">
              <Card>
                <CardHeader>
                  <CardTitle>Savings Transaction History</CardTitle>
                  <CardDescription>
                    All savings deposits and withdrawals
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Previous Balance</TableHead>
                        <TableHead>New Balance</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Processed By</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {savingsTransactions.map((transaction) => (
                        <TableRow key={transaction.id}>
                          <TableCell>
                            {format(new Date(transaction.createdAt), 'MMM dd, yyyy HH:mm')}
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={transaction.transactionType === 'deposit' ? 'default' : 'destructive'}
                              className="flex items-center gap-1 w-fit"
                            >
                              {getTransactionIcon(transaction.transactionType, transaction.amount)}
                              {transaction.transactionType === 'deposit' ? 'Deposit' : 'Withdrawal'}
                            </Badge>
                          </TableCell>
                          <TableCell className={getTransactionColor(transaction.transactionType)}>
                            {formatCurrency(transaction.amount)}
                          </TableCell>
                          <TableCell>
                            {formatCurrency(transaction.previousBalance || 0)}
                          </TableCell>
                          <TableCell className="font-medium">
                            {formatCurrency(transaction.newBalance || 0)}
                          </TableCell>
                          <TableCell>
                            {transaction.description || 'No description'}
                          </TableCell>
                          <TableCell>
                            {transaction.processorName || 'System'}
                          </TableCell>
                        </TableRow>
                      ))}
                      {savingsTransactions.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center text-muted-foreground">
                            No savings transactions found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payments">
              <Card>
                <CardHeader>
                  <CardTitle>Loan Payment History</CardTitle>
                  <CardDescription>
                    All verified loan payments
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Loan ID</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Note</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paymentHistory.map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell>
                            {format(new Date(payment.datePaid), 'MMM dd, yyyy HH:mm')}
                          </TableCell>
                          <TableCell className="font-medium text-green-600">
                            {formatCurrency(payment.amount)}
                          </TableCell>
                          <TableCell>#{payment.loanId}</TableCell>
                          <TableCell>
                            <Badge variant={payment.status === 'verified' ? 'default' : 'secondary'}>
                              {payment.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {payment.paymentMethod || 'Counter'}
                          </TableCell>
                          <TableCell>
                            {payment.paymentNote || 'No note'}
                          </TableCell>
                        </TableRow>
                      ))}
                      {paymentHistory.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground">
                            No payment history found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}