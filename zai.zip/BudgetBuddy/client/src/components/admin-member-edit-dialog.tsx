import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { User, CapitalShare, MemberSavings } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Eye, EyeOff, DollarSign, Plus, Minus, History, Wallet, PiggyBank } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";
import { MemberTransactionHistory } from "./member-transaction-history";

const memberEditSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  middleName: z.string().optional(),
  email: z.string().email("Invalid email address"),
  address: z.string().optional(),
  occupation: z.string().optional(),
  birthplace: z.string().optional(),
  contactNumber: z.string().optional(),
  civilStatus: z.string().optional(),
  numberOfChildren: z.coerce.number().min(0).optional(),
  parentsName: z.string().optional(),
  sourceOfIncome: z.string().optional(),
  status: z.enum(["active", "inactive", "pending"]),
});

const passwordResetSchema = z.object({
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const cbuUpdateSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive"),
  operation: z.enum(["add", "deduct", "set"]),
  description: z.string().optional(),
});

const savingsTransactionSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive"),
  transactionType: z.enum(["deposit", "withdrawal"]),
  description: z.string().optional(),
});

type MemberEditDialogProps = {
  member: User | null;
  isOpen: boolean;
  onClose: () => void;
};

export function AdminMemberEditDialog({ member, isOpen, onClose }: MemberEditDialogProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const { toast } = useToast();

  const memberForm = useForm<z.infer<typeof memberEditSchema>>({
    resolver: zodResolver(memberEditSchema),
    defaultValues: {
      name: "",
      firstName: "",
      lastName: "",
      middleName: "",
      email: "",
      address: "",
      occupation: "",
      birthplace: "",
      contactNumber: "",
      civilStatus: "",
      numberOfChildren: 0,
      parentsName: "",
      sourceOfIncome: "",
      status: "active",
    },
  });

  const passwordForm = useForm<z.infer<typeof passwordResetSchema>>({
    resolver: zodResolver(passwordResetSchema),
    defaultValues: {
      newPassword: "",
      confirmPassword: "",
    },
  });

  const cbuForm = useForm<z.infer<typeof cbuUpdateSchema>>({
    resolver: zodResolver(cbuUpdateSchema),
    defaultValues: {
      amount: 0,
      operation: "add",
      description: "",
    },
  });

  const savingsForm = useForm<z.infer<typeof savingsTransactionSchema>>({
    resolver: zodResolver(savingsTransactionSchema),
    defaultValues: {
      amount: 0,
      transactionType: "deposit",
      description: "",
    },
  });

  // Get member's capital share
  const { data: capitalShare, refetch: refetchCapitalShare } = useQuery<CapitalShare>({
    queryKey: ["/api/members/capital-shares", member?.id],
    queryFn: async () => {
      const response = await fetch(`/api/members/capital-shares?userId=${member?.id}`);
      if (!response.ok) throw new Error('Failed to fetch capital share');
      return response.json();
    },
    enabled: !!member?.id && isOpen,
    refetchOnWindowFocus: true,
    staleTime: 0, // Always consider data stale for immediate updates
  });

  // Get member's savings
  const { data: savingsData, refetch: refetchSavings } = useQuery<{transactions: MemberSavings[], balance: number}>({
    queryKey: [`/api/admin/members/${member?.id}/savings`],
    enabled: !!member?.id && isOpen,
    refetchOnWindowFocus: true,
    staleTime: 0, // Always consider data stale for immediate updates
  });

  // Update member information
  const updateMemberMutation = useMutation({
    mutationFn: async (data: z.infer<typeof memberEditSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to update member");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Member information updated successfully",
      });
      // Invalidate all member-related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members/inactive"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members/"] });
      // Don't close dialog immediately to show the update
    },
    onError: (error) => {
      console.error("Update member error:", error);
      toast({
        title: "Error",
        description: "Failed to update member information",
        variant: "destructive",
      });
    },
  });

  // Reset password
  const resetPasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof passwordResetSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}/reset-password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ newPassword: data.newPassword }),
      });
      if (!response.ok) throw new Error("Failed to reset password");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Password reset successfully",
      });
      passwordForm.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reset password",
        variant: "destructive",
      });
    },
  });

  // Update CBU
  const updateCBUMutation = useMutation({
    mutationFn: async (data: z.infer<typeof cbuUpdateSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}/capital-shares`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(errorData || "Failed to update CBU");
      }
      return response.json();
    },
    onSuccess: (data) => {
      // Optimistically update the capital share data in cache
      queryClient.setQueryData(["/api/members/capital-shares", member?.id], data);
      
      toast({
        title: "Success",
        description: "CBU amount updated successfully",
      });
      
      // Force immediate refetch to ensure UI consistency
      setTimeout(() => {
        refetchCapitalShare();
      }, 100);
      
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["/api/members/capital-shares"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/capital-shares"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members/inactive"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members", member?.id, "transactions"] });
      
      cbuForm.reset();
    },
    onError: (error) => {
      console.error("CBU update error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to update CBU amount",
        variant: "destructive",
      });
    },
  });

  // Add savings transaction
  const addSavingsMutation = useMutation({
    mutationFn: async (data: z.infer<typeof savingsTransactionSchema>) => {
      console.log("Sending savings transaction:", data);
      const response = await fetch(`/api/admin/members/${member?.id}/savings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const errorData = await response.text();
        console.error("Savings transaction error:", errorData);
        throw new Error(errorData || "Failed to add savings transaction");
      }
      const result = await response.json();
      console.log("Savings transaction result:", result);
      return result;
    },
    onSuccess: (data) => {
      console.log("Savings success with data:", data);
      
      toast({
        title: "Success",
        description: `₱${data.amount.toLocaleString('en-PH')} ${data.transactionType} processed. New balance: ₱${data.balance.toLocaleString('en-PH')}`,
      });
      
      // Reset form immediately
      savingsForm.reset();
      
      // Force immediate refetch and invalidate all caches
      queryClient.invalidateQueries({ queryKey: [`/api/admin/members/${member?.id}/savings`] });
      queryClient.removeQueries({ queryKey: [`/api/admin/members/${member?.id}/savings`] });
      
      // Refresh the data immediately
      setTimeout(() => {
        refetchSavings();
      }, 50);
    },
    onError: (error) => {
      console.error("Savings transaction error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to add savings transaction",
        variant: "destructive",
      });
    },
  });

  // Update form values when member changes
  useEffect(() => {
    if (member) {
      memberForm.reset({
        name: member.name || "",
        firstName: member.firstName || "",
        lastName: member.lastName || "",
        middleName: member.middleName || "",
        email: member.email || "",
        address: member.address || "",
        occupation: member.occupation || "",
        birthplace: member.birthplace || "",
        contactNumber: member.contactNumber || "",
        civilStatus: member.civilStatus || "",
        numberOfChildren: member.numberOfChildren || 0,
        parentsName: member.parentsName || "",
        sourceOfIncome: member.sourceOfIncome || "",
        status: member.status as "active" | "inactive" | "pending",
      });
    }
  }, [member, memberForm]);

  // Force refresh queries when dialog opens or member changes
  useEffect(() => {
    if (member?.id && isOpen) {
      refetchCapitalShare();
      refetchSavings();
    }
  }, [member?.id, isOpen, refetchCapitalShare, refetchSavings]);

  // Add effect to refetch data periodically to ensure UI stays current
  useEffect(() => {
    if (member?.id && isOpen) {
      // Remove cached data and force fresh fetch
      queryClient.removeQueries({ queryKey: ["/api/admin/members", member.id, "savings"] });
      
      const interval = setInterval(() => {
        queryClient.removeQueries({ queryKey: ["/api/admin/members", member.id, "savings"] });
        refetchSavings();
      }, 3000); // Refresh every 3 seconds when dialog is open
      
      return () => clearInterval(interval);
    }
  }, [member?.id, isOpen, refetchSavings, queryClient]);

  const onSubmitMember = (data: z.infer<typeof memberEditSchema>) => {
    updateMemberMutation.mutate(data);
  };

  const onSubmitPassword = (data: z.infer<typeof passwordResetSchema>) => {
    resetPasswordMutation.mutate(data);
  };

  const onSubmitCBU = (data: z.infer<typeof cbuUpdateSchema>) => {
    updateCBUMutation.mutate(data);
  };

  const onSubmitSavings = (data: z.infer<typeof savingsTransactionSchema>) => {
    addSavingsMutation.mutate(data);
  };

  // Simple transaction history component
  const SimpleTransactionHistory = ({ memberId }: { memberId: number }) => {
    const { data: transactionHistory, isLoading } = useQuery({
      queryKey: ['/api/admin/members', memberId, 'transactions'],
      enabled: activeTab === "history" && !!memberId
    });

    if (isLoading) {
      return (
        <div className="flex items-center justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      );
    }

    const capitalShareTransactions = (transactionHistory as any)?.capitalShareTransactions || [];
    const savingsTransactions = (transactionHistory as any)?.savingsTransactions || [];
    const paymentHistory = (transactionHistory as any)?.paymentHistory || [];

    return (
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="cbu-history">CBU History</TabsTrigger>
          <TabsTrigger value="savings-history">Savings History</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{capitalShareTransactions.length}</div>
                <div className="text-sm text-muted-foreground">CBU Transactions</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{savingsTransactions.length}</div>
                <div className="text-sm text-muted-foreground">Savings Transactions</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{paymentHistory.length}</div>
                <div className="text-sm text-muted-foreground">Loan Payments</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cbu-history">
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Previous</TableHead>
                  <TableHead>New Balance</TableHead>
                  <TableHead>Description</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {capitalShareTransactions.map((transaction: any) => (
                  <TableRow key={transaction.id}>
                    <TableCell>
                      {format(new Date(transaction.createdAt), 'MMM dd, yyyy HH:mm')}
                    </TableCell>
                    <TableCell>
                      <Badge variant={transaction.transactionType === 'add' ? 'default' : 'destructive'}>
                        {transaction.transactionType === 'add' ? 'Addition' : 'Deduction'}
                      </Badge>
                    </TableCell>
                    <TableCell>₱{transaction.amount?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>₱{transaction.previousAmount?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>₱{transaction.newAmount?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>{transaction.description || 'No description'}</TableCell>
                  </TableRow>
                ))}
                {capitalShareTransactions.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      No CBU transactions found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="savings-history">
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Previous</TableHead>
                  <TableHead>New Balance</TableHead>
                  <TableHead>Description</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {savingsTransactions.map((transaction: any) => (
                  <TableRow key={transaction.id}>
                    <TableCell>
                      {format(new Date(transaction.createdAt), 'MMM dd, yyyy HH:mm')}
                    </TableCell>
                    <TableCell>
                      <Badge variant={transaction.transactionType === 'deposit' ? 'default' : 'destructive'}>
                        {transaction.transactionType === 'deposit' ? 'Deposit' : 'Withdrawal'}
                      </Badge>
                    </TableCell>
                    <TableCell>₱{transaction.amount?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>₱{transaction.previousBalance?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>₱{transaction.newBalance?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>{transaction.description || 'No description'}</TableCell>
                  </TableRow>
                ))}
                {savingsTransactions.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      No savings transactions found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="payments">
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Note</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paymentHistory.map((payment: any) => (
                  <TableRow key={payment.id}>
                    <TableCell>
                      {format(new Date(payment.datePaid), 'MMM dd, yyyy HH:mm')}
                    </TableCell>
                    <TableCell>₱{payment.amount?.toLocaleString('en-PH', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}</TableCell>
                    <TableCell>
                      <Badge variant={payment.status === 'verified' ? 'default' : 'secondary'}>
                        {payment.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{payment.paymentMethod || 'Counter'}</TableCell>
                    <TableCell>{payment.paymentNote || 'No note'}</TableCell>
                  </TableRow>
                ))}
                {paymentHistory.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">
                      No payment history found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    );
  };

  if (!member) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Member - {member.name}</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="cbu">CBU</TabsTrigger>
            <TabsTrigger value="savings">Savings</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Member Information</CardTitle>
                <CardDescription>Update member's personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={memberForm.handleSubmit(onSubmitMember)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        {...memberForm.register("name")}
                        placeholder="Enter full name"
                      />
                      {memberForm.formState.errors.name && (
                        <p className="text-sm text-red-500">{memberForm.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        {...memberForm.register("email")}
                        placeholder="Enter email address"
                      />
                      {memberForm.formState.errors.email && (
                        <p className="text-sm text-red-500">{memberForm.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        {...memberForm.register("firstName")}
                        placeholder="Enter first name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        {...memberForm.register("lastName")}
                        placeholder="Enter last name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="middleName">Middle Name</Label>
                      <Input
                        id="middleName"
                        {...memberForm.register("middleName")}
                        placeholder="Enter middle name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contactNumber">Contact Number</Label>
                      <Input
                        id="contactNumber"
                        {...memberForm.register("contactNumber")}
                        placeholder="Enter contact number"
                      />
                    </div>

                    <div>
                      <Label htmlFor="occupation">Occupation</Label>
                      <Input
                        id="occupation"
                        {...memberForm.register("occupation")}
                        placeholder="Enter occupation"
                      />
                    </div>

                    <div>
                      <Label htmlFor="civilStatus">Civil Status</Label>
                      <Select
                        value={memberForm.watch("civilStatus") || ""}
                        onValueChange={(value) => memberForm.setValue("civilStatus", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select civil status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="single">Single</SelectItem>
                          <SelectItem value="married">Married</SelectItem>
                          <SelectItem value="divorced">Divorced</SelectItem>
                          <SelectItem value="widowed">Widowed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="numberOfChildren">Number of Children</Label>
                      <Input
                        id="numberOfChildren"
                        type="number"
                        min="0"
                        {...memberForm.register("numberOfChildren")}
                        placeholder="Enter number of children"
                      />
                    </div>

                    <div>
                      <Label htmlFor="status">Status</Label>
                      <Select
                        value={memberForm.watch("status")}
                        onValueChange={(value) => memberForm.setValue("status", value as "active" | "inactive" | "pending")}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="address">Address</Label>
                      <Textarea
                        id="address"
                        {...memberForm.register("address")}
                        placeholder="Enter complete address"
                      />
                    </div>

                    <div>
                      <Label htmlFor="birthplace">Birthplace</Label>
                      <Input
                        id="birthplace"
                        {...memberForm.register("birthplace")}
                        placeholder="Enter birthplace"
                      />
                    </div>

                    <div>
                      <Label htmlFor="parentsName">Parents Name</Label>
                      <Input
                        id="parentsName"
                        {...memberForm.register("parentsName")}
                        placeholder="Enter parents name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="sourceOfIncome">Source of Income</Label>
                      <Input
                        id="sourceOfIncome"
                        {...memberForm.register("sourceOfIncome")}
                        placeholder="Enter source of income"
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={updateMemberMutation.isPending}
                    className="w-full"
                  >
                    {updateMemberMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Update Member Information
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Password Reset</CardTitle>
                <CardDescription>Reset member's password</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={passwordForm.handleSubmit(onSubmitPassword)} className="space-y-4">
                  <div>
                    <Label htmlFor="newPassword">New Password</Label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        type={showPassword ? "text" : "password"}
                        {...passwordForm.register("newPassword")}
                        placeholder="Enter new password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    {passwordForm.formState.errors.newPassword && (
                      <p className="text-sm text-red-500">{passwordForm.formState.errors.newPassword.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      {...passwordForm.register("confirmPassword")}
                      placeholder="Confirm new password"
                    />
                    {passwordForm.formState.errors.confirmPassword && (
                      <p className="text-sm text-red-500">{passwordForm.formState.errors.confirmPassword.message}</p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    disabled={resetPasswordMutation.isPending}
                    className="w-full"
                  >
                    {resetPasswordMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Reset Password
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cbu" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Capital Build-Up (CBU)</CardTitle>
                <CardDescription>Manage member's capital shares</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-5 w-5 text-primary" />
                      <div>
                        <p className="text-sm text-muted-foreground">Current CBU Amount</p>
                        <p className="text-2xl font-bold">
                          ₱{capitalShare?.amount ? capitalShare.amount.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) : "0.00"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <form onSubmit={cbuForm.handleSubmit(onSubmitCBU)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="cbuAmount">Amount</Label>
                        <Input
                          id="cbuAmount"
                          type="number"
                          step="0.01"
                          min="0.01"
                          {...cbuForm.register("amount")}
                          placeholder="Enter amount"
                        />
                        {cbuForm.formState.errors.amount && (
                          <p className="text-sm text-red-500">{cbuForm.formState.errors.amount.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="operation">Operation</Label>
                        <Select
                          value={cbuForm.watch("operation")}
                          onValueChange={(value) => cbuForm.setValue("operation", value as "add" | "deduct" | "set")}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select operation" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="add">
                              <div className="flex items-center">
                                <Plus className="mr-2 h-4 w-4 text-green-500" />
                                Add to CBU
                              </div>
                            </SelectItem>
                            <SelectItem value="deduct">
                              <div className="flex items-center">
                                <Minus className="mr-2 h-4 w-4 text-red-500" />
                                Deduct from CBU
                              </div>
                            </SelectItem>
                            <SelectItem value="set">
                              <div className="flex items-center">
                                <DollarSign className="mr-2 h-4 w-4 text-blue-500" />
                                Set Total Amount
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="cbuDescription">Description (Optional)</Label>
                      <Textarea
                        id="cbuDescription"
                        {...cbuForm.register("description")}
                        placeholder="Enter transaction description"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      disabled={updateCBUMutation.isPending}
                      className="w-full"
                    >
                      {updateCBUMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      {cbuForm.watch("operation") === "add" && "Add to CBU"}
                      {cbuForm.watch("operation") === "deduct" && "Deduct from CBU"}
                      {cbuForm.watch("operation") === "set" && "Set CBU Amount"}
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="savings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Member Savings</CardTitle>
                <CardDescription>Manage member's savings account</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-5 w-5 text-primary" />
                      <div>
                        <p className="text-sm text-muted-foreground">Current Savings Balance</p>
                        <p className="text-2xl font-bold">
                          ₱{savingsData?.balance ? savingsData.balance.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) : "0.00"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <form onSubmit={savingsForm.handleSubmit(onSubmitSavings)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="savingsAmount">Amount</Label>
                        <Input
                          id="savingsAmount"
                          type="number"
                          step="0.01"
                          min="0.01"
                          {...savingsForm.register("amount")}
                          placeholder="Enter amount"
                        />
                        {savingsForm.formState.errors.amount && (
                          <p className="text-sm text-red-500">{savingsForm.formState.errors.amount.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="transactionType">Transaction Type</Label>
                        <Select
                          value={savingsForm.watch("transactionType")}
                          onValueChange={(value) => savingsForm.setValue("transactionType", value as "deposit" | "withdrawal")}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select transaction type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="deposit">
                              <div className="flex items-center">
                                <Plus className="mr-2 h-4 w-4 text-green-500" />
                                Deposit
                              </div>
                            </SelectItem>
                            <SelectItem value="withdrawal">
                              <div className="flex items-center">
                                <Minus className="mr-2 h-4 w-4 text-red-500" />
                                Withdrawal
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">Description (Optional)</Label>
                      <Textarea
                        id="description"
                        {...savingsForm.register("description")}
                        placeholder="Enter transaction description"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      disabled={addSavingsMutation.isPending}
                      className="w-full"
                    >
                      {addSavingsMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Process Transaction
                    </Button>
                  </form>

                  {savingsData?.transactions && savingsData.transactions.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium mb-2">Recent Transactions</h4>
                      <div className="border rounded-lg">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead>Amount</TableHead>
                              <TableHead>Balance</TableHead>
                              <TableHead>Note</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {savingsData.transactions.slice(0, 5).map((transaction) => (
                              <TableRow key={transaction.id}>
                                <TableCell>
                                  {format(new Date(transaction.date), "MMM d, yyyy")}
                                </TableCell>
                                <TableCell>
                                  <div className={`flex items-center ${
                                    transaction.transactionType === 'deposit' ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {transaction.transactionType === 'deposit' ? (
                                      <Plus className="mr-1 h-3 w-3" />
                                    ) : (
                                      <Minus className="mr-1 h-3 w-3" />
                                    )}
                                    {transaction.transactionType}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  ₱{transaction.amount.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                  })}
                                </TableCell>
                                <TableCell>
                                  ₱{transaction.balance.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                  })}
                                </TableCell>
                                <TableCell>{transaction.note || "-"}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Transaction History
                </CardTitle>
                <CardDescription>
                  Complete transaction history for this member including CBU, savings, and payments
                </CardDescription>
              </CardHeader>
              <CardContent>
                {activeTab === "history" && (
                  <SimpleTransactionHistory memberId={member.id} />
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}