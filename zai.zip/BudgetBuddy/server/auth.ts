import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";

declare global {
  namespace Express {
    // Define User interface for Express sessions
    interface User {
      id: number;
      email: string;
      name: string;
      role: string;
      [key: string]: any; // Allow any other properties from the User schema
    }
  }
}

const scryptAsync = promisify(scrypt);

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}.${buf.toString("hex")}`;
}

async function comparePasswords(supplied: string, stored: string) {
  try {
    // Check if stored password has the expected format (salt.hash)
    if (!stored || !stored.includes(".")) {
      console.log("Password is not in the expected format (salt.hash)");
      return false;
    }

    const [salt, hashed] = stored.split(".");
    
    if (!hashed || !salt) {
      console.log("Invalid password format: missing hash or salt");
      return false;
    }

    // Validate hex format and length
    let hashedBuf;
    try {
      hashedBuf = Buffer.from(hashed, "hex");
      if (hashedBuf.length !== 64) {
        console.log(`Invalid hash length: expected 64 bytes, got ${hashedBuf.length}`);
        return false;
      }
    } catch (hexError) {
      console.log("Invalid hex format in stored hash");
      return false;
    }

    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    
    // Ensure both buffers are exactly 64 bytes before comparison
    if (hashedBuf.length !== 64 || suppliedBuf.length !== 64) {
      console.log(`Buffer length issue: stored=${hashedBuf.length}, supplied=${suppliedBuf.length}`);
      return false;
    }

    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error("Error comparing passwords:", error);
    return false;
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "hopempc-secret-key",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        console.log("Local strategy authenticating email:", email);
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            console.log("User not found with email:", email);
            return done(null, false);
          }
          
          const passwordMatch = await comparePasswords(password, user.password);
          if (!passwordMatch) {
            console.log("Password does not match for user:", email);
            return done(null, false);
          }
          
          console.log("Authentication successful for user:", { id: user.id, email: user.email });
          return done(null, user);
        } catch (error) {
          console.error("Error in local strategy:", error);
          return done(error);
        }
      },
    ),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    const user = await storage.getUser(id);
    done(null, user);
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      console.log("Registration request body:", req.body);
      
      const existingUser = await storage.getUserByEmail(req.body.email);
      if (existingUser) {
        console.log("Email already exists:", req.body.email);
        return res.status(400).json({ message: "Email already exists" });
      }

      console.log("Creating new user:", { ...req.body, password: "[FILTERED]" });
      const user = await storage.createUser({
        ...req.body,
        password: await hashPassword(req.body.password),
      });
      console.log("User created successfully:", { id: user.id, name: user.name, email: user.email, role: user.role });

      // Create initial capital share of 0
      console.log("Creating initial capital share for user ID:", user.id);
      await storage.addCapitalShare({
        userId: user.id,
        amount: 0
      });
      console.log("Capital share created successfully");

      console.log("Logging in user:", user.id);
      req.login(user, (err) => {
        if (err) {
          console.error("Login error after registration:", err);
          return next(err);
        }
        console.log("User logged in successfully after registration");
        res.status(201).json(user);
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Internal server error during registration" });
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log("Login request body:", { email: req.body.email, password: "[FILTERED]" });
    
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        console.error("Passport authentication error:", err);
        return next(err);
      }
      if (!user) {
        console.log("Authentication failed: Invalid email or password");
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      console.log("User authenticated successfully, logging in:", { id: user.id, email: user.email, role: user.role });
      req.login(user, (err) => {
        if (err) {
          console.error("Login error:", err);
          return next(err);
        }
        console.log("User logged in successfully");
        return res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
