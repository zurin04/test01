#!/bin/bash

# HOPEMPC Production Deployment Script
# Optimized one-click deployment for Ubuntu VPS

set -e

echo "======================================"
echo "HOPEMPC Production Deployment"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx certbot python3-certbot-nginx python3

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application
APP_DIR="/var/www/hopempc"
print_status "Setting up application..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR
cp -r . $APP_DIR/ && cd $APP_DIR

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS hopempc_db;
DROP USER IF EXISTS hopempc_user;
CREATE USER hopempc_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE hopempc_db OWNER hopempc_user;
GRANT ALL PRIVILEGES ON DATABASE hopempc_db TO hopempc_user;
\q
EOF

# Create environment file (will be updated after database setup)
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
ENV

# Install dependencies 
print_status "Installing dependencies..."
npm install

# Setup database schema and seed data
print_status "Initializing database..."

# URL encode the password to handle special characters
if command -v python3 >/dev/null 2>&1; then
    DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
else
    print_warning "Python3 not available, using password as-is (may cause issues with special characters)"
    DB_PASSWORD_ENCODED="$DB_PASSWORD"
fi
export DATABASE_URL="postgresql://hopempc_user:$DB_PASSWORD_ENCODED@localhost:5432/hopempc_db"
export SESSION_SECRET
export NODE_ENV=production

# Test database connection first
print_status "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U hopempc_user -d hopempc_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi

print_status "Pushing database schema..."
# Try with encoded URL first, then fallback to direct connection
if ! npm run db:push 2>&1; then
    print_warning "Schema push with encoded URL failed, trying direct connection..."
    # Try with raw password
    export DATABASE_URL="postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db"
    if ! npm run db:push 2>&1; then
        print_error "Database schema push failed with both URL formats."
        exit 1
    fi
fi

print_status "Seeding database..."
if ! npx tsx db/simple-seed.ts 2>&1; then
    print_warning "Seeding with current URL failed, trying with raw password..."
    export DATABASE_URL="postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db"
    if ! npx tsx db/simple-seed.ts 2>&1; then
        print_error "Database seeding failed with both URL formats."
        exit 1
    fi
fi

# Update .env file with working DATABASE_URL
print_status "Updating environment configuration with working database URL..."
cat > .env << ENV
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
ENV

# Fix any password format issues
print_status "Fixing password formats..."
npx tsx db/fix-all-passwords.ts 2>/dev/null || echo "Password fix utility not needed or already applied"

# Build application
print_status "Building application..."
npm run build

# Configure PM2 and services
print_status "Configuring services..."
mkdir -p logs

# Determine which URL format worked
WORKING_DB_URL="$DATABASE_URL"

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'hopempc',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: '$WORKING_DB_URL',
      SESSION_SECRET: '$SESSION_SECRET'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}
EOF

# Configure Nginx
sudo tee /etc/nginx/sites-available/hopempc > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
}
EOF

sudo ln -sf /etc/nginx/sites-available/hopempc /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "hopempc.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs hopempc"
    exit 1
fi

# Setup security and management
print_status "Finalizing setup..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Create enhanced management script
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/hopempc"
APP_DIR="/var/www/hopempc"

backup_database() {
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    echo "Creating database backup..."
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$DB_PASSWORD" ]; then
        # Extract password from DATABASE_URL if DB_PASSWORD not set
        DB_PASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump -h localhost -U hopempc_user hopempc_db > $BACKUP_FILE; then
        echo "✓ Backup saved to: $BACKUP_FILE"
        # Keep only last 7 backups
        ls -t $BACKUP_DIR/backup_*.sql | tail -n +8 | xargs -r rm
        echo "✓ Old backups cleaned up (keeping last 7)"
    else
        echo "✗ Backup failed!"
        exit 1
    fi
}

restore_database() {
    local backup_file=$2
    if [ -z "$backup_file" ]; then
        echo "Available backups:"
        ls -la $BACKUP_DIR/backup_*.sql 2>/dev/null || echo "No backups found"
        echo "Usage: $0 restore /path/to/backup.sql"
        exit 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        echo "✗ Backup file not found: $backup_file"
        exit 1
    fi
    
    echo "⚠️  WARNING: This will replace all current data!"
    echo "Press Enter to continue or Ctrl+C to cancel..."
    read
    
    echo "Stopping application..."
    pm2 stop hopempc
    
    echo "Restoring database from: $backup_file"
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$DB_PASSWORD" ]; then
        DB_PASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$DB_PASSWORD" psql -h localhost -U hopempc_user -d hopempc_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" && \
       PGPASSWORD="$DB_PASSWORD" psql -h localhost -U hopempc_user hopempc_db < $backup_file; then
        echo "✓ Database restored successfully"
        pm2 start hopempc
        echo "✓ Application restarted"
    else
        echo "✗ Restore failed!"
        pm2 start hopempc
        exit 1
    fi
}

safe_update() {
    echo "Starting safe update process..."
    
    # Create pre-update backup
    echo "Creating pre-update backup..."
    backup_database
    
    # Stop application
    echo "Stopping application..."
    pm2 stop hopempc
    
    # Update code
    echo "Pulling latest changes..."
    if git pull; then
        echo "✓ Code updated"
    else
        echo "✗ Git pull failed!"
        pm2 start hopempc
        exit 1
    fi
    
    # Install dependencies
    echo "Installing dependencies..."
    if npm install; then
        echo "✓ Dependencies updated"
    else
        echo "✗ npm install failed!"
        pm2 start hopempc
        exit 1
    fi
    
    # Update database schema
    echo "Updating database schema..."
    if npm run db:push; then
        echo "✓ Database schema updated"
    else
        echo "✗ Database migration failed!"
        echo "Restoring from backup..."
        # Find the most recent backup
        LATEST_BACKUP=$(ls -t $BACKUP_DIR/backup_*.sql | head -1)
        restore_database restore $LATEST_BACKUP
        exit 1
    fi
    
    # Build application
    echo "Building application..."
    if npm run build; then
        echo "✓ Application built"
    else
        echo "✗ Build failed!"
        pm2 start hopempc
        exit 1
    fi
    
    # Start application
    echo "Starting application..."
    pm2 start hopempc
    
    # Verify application is running
    sleep 5
    if pm2 list | grep -q "hopempc.*online"; then
        echo "✓ Update completed successfully!"
    else
        echo "✗ Application failed to start after update!"
        echo "Check logs with: pm2 logs hopempc"
    fi
}

ssl_setup() {
    local domain=$2
    if [ -z "$domain" ]; then
        echo "Usage: $0 ssl yourdomain.com"
        exit 1
    fi
    
    echo "Setting up SSL for domain: $domain"
    
    # Update Nginx config
    sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/hopempc
    sudo nginx -t && sudo systemctl reload nginx
    
    # Get SSL certificate
    if sudo certbot --nginx -d "$domain" --non-interactive --agree-tos --email "admin@$domain" --redirect; then
        echo "✓ SSL certificate installed successfully!"
        # Setup automatic renewal
        (sudo crontab -l 2>/dev/null | grep -v "certbot renew"; echo "0 12 * * * /usr/bin/certbot renew --quiet") | sudo crontab -
        echo "✓ Automatic renewal configured"
    else
        echo "✗ SSL certificate installation failed. Check DNS configuration."
        exit 1
    fi
}

case "$1" in
    start|stop|restart) 
        pm2 $1 hopempc 
        ;;
    status) 
        pm2 status && echo "" && pm2 logs hopempc --lines 10 
        ;;
    logs) 
        pm2 logs hopempc 
        ;;
    update) 
        safe_update 
        ;;
    backup) 
        backup_database 
        ;;
    restore) 
        restore_database $@ 
        ;;
    ssl) 
        ssl_setup $@ 
        ;;
    *) 
        echo "HOPEMPC Management Script"
        echo "========================"
        echo "Usage: $0 {command} [options]"
        echo ""
        echo "Commands:"
        echo "  start          - Start the application"
        echo "  stop           - Stop the application"
        echo "  restart        - Restart the application"
        echo "  status         - Show application status and recent logs"
        echo "  logs           - Show real-time logs"
        echo "  update         - Safe update (backup, pull, build, restart)"
        echo "  backup         - Create database backup"
        echo "  restore <file> - Restore database from backup"
        echo "  ssl <domain>   - Setup SSL certificate for domain"
        echo ""
        echo "Examples:"
        echo "  $0 status"
        echo "  $0 backup"
        echo "  $0 restore /var/backups/hopempc/backup_20241227_143000.sql"
        echo "  $0 ssl hopempc.yourdomain.com"
        ;;
esac
SCRIPT
chmod +x manage.sh

# Setup automatic backups
(crontab -l 2>/dev/null | grep -v "hopempc backup"; echo "0 2 * * * $APP_DIR/manage.sh backup") | crontab -

# Get server info
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

# SSL Certificate Setup
setup_ssl() {
    local domain=$1
    if [[ -n "$domain" && "$domain" != "localhost" && "$domain" != "$SERVER_IP" ]]; then
        print_status "Setting up SSL certificate for $domain..."
        
        # Update Nginx config with domain name
        sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/hopempc
        sudo nginx -t && sudo systemctl reload nginx
        
        # Get SSL certificate
        if sudo certbot --nginx -d "$domain" --non-interactive --agree-tos --email "admin@$domain" --redirect; then
            print_status "SSL certificate installed successfully!"
            # Setup automatic renewal
            (sudo crontab -l 2>/dev/null | grep -v "certbot renew"; echo "0 12 * * * /usr/bin/certbot renew --quiet") | sudo crontab -
        else
            print_warning "SSL certificate installation failed. Check DNS configuration."
        fi
    else
        print_warning "No valid domain provided. Skipping SSL setup."
        print_warning "To setup SSL later, run: sudo certbot --nginx -d yourdomain.com"
    fi
}

# Prompt for SSL setup
echo ""
print_status "Do you want to setup SSL certificate? (requires domain name)"
read -p "Enter domain name (e.g., hopempc.yourdomain.com) or press Enter to skip: " DOMAIN

if [[ -n "$DOMAIN" ]]; then
    setup_ssl "$DOMAIN"
    SITE_URL="https://$DOMAIN"
else
    SITE_URL="http://$SERVER_IP"
fi

# Create deployment info
cat > deployment-info.txt << INFO
HOPEMPC Deployment Complete
===========================
Date: $(date)
Server: $SITE_URL
Database Password: $DB_PASSWORD

Default Credentials:
- Admin: admin@hopempc.org / admin123
- Member: member@hopempc.org / member123

Management Commands:
- ./manage.sh status           # Check status and recent logs
- ./manage.sh restart          # Restart application
- ./manage.sh logs             # View real-time logs
- ./manage.sh update           # Safe update (backup, pull, build, restart)
- ./manage.sh backup           # Create database backup
- ./manage.sh restore <file>   # Restore from backup
- ./manage.sh ssl <domain>     # Setup SSL certificate

System Services:
- nginx: sudo systemctl status nginx
- postgresql: sudo systemctl status postgresql  
- pm2: pm2 status

Backup Information:
- Automatic daily backups at 2:00 AM
- Backups stored in: /var/backups/hopempc/
- Retention: Last 7 backups kept automatically

Security Features:
- Firewall configured (ports 22, 80, 443)
- SSL certificates auto-renewal $([ -n "$DOMAIN" ] && echo "✓ ENABLED" || echo "✗ Not configured")
- Session encryption enabled
- Database password protection

IMPORTANT: 
1. Change default passwords after first login!
2. Setup SSL if not done during installation: ./manage.sh ssl yourdomain.com
3. Regular backups: ./manage.sh backup
INFO

echo ""
print_status "Deployment completed successfully!"
print_status "Application URL: $SITE_URL"
print_status "Admin login: admin@hopempc.org / admin123"
print_status "Management script: ./manage.sh"
print_status "Check ./deployment-info.txt for complete details"
echo ""
print_warning "Remember to change default passwords after first login!"
[[ -z "$DOMAIN" ]] && print_warning "Setup SSL later with: ./manage.sh ssl yourdomain.com"
echo ""